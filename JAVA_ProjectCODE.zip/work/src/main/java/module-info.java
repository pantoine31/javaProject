module gui.work {
    requires javafx.controls;
	requires javafx.graphics;
	requires java.desktop;
	requires javafx.base;
    exports gui.work;
}
