package gui.work;

import java.util.ArrayList;
import java.util.List;

import javax.swing.JComboBox;

import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;

//Scene of Clients
//This scene shows up when we click clientsBtn



//Creator of Clients Scene
public class ClientsSceneCreator extends SceneCreator implements EventHandler<MouseEvent> {
	
	// dhlwsh statherwn
	private static String Email;
	private static long Phone;
	private static long AFM;
	
	// 2 arrays for ids and afms
	List<String>idList = new ArrayList<String>();
	static List<Long>afmsList = new ArrayList<Long>();

	// Array list for saving our objects. The Type Of our list is Client.
	static List<Client>clientList = new ArrayList<Client>();
	
	// Client Scene Flow Pane (root node)   
	FlowPane buttonFlowPane; 
	
	// Client Scene Grid Pane
	GridPane rootGridPane , inputFieldsPane;
	
	// Buttons of Client Scene
	Button newBtn , refreshBtn , deleteBtn , searchafmBtn , searchidBtn ,backBtn;
	
	// Labels of Clients Scene (these labels are on inputFieldsPane)
	Label searchafmLbl ,searchidLbl, idLbl , afmLbl , fullNameLbl , occLbl , adrrLbl , phoneLbl , emailLbl , newLbl;
	
	// TextFields of Client Scene (these labels are on inputFieldsPane)
	TextField searchFieldafm ,searchFieldid, idField , afmField , fullNameField , occField , addrField , phoneField , emailField;
	
	
	// TableView of Client Scene (TableView is on GridPane)
	TableView<Client> clientTableView;
	
	// counter 
			int i = 0;
	
	// Constructor from superclass
	public ClientsSceneCreator(double width, double height) {
		super(width, height);
		
		// create objectives
		rootGridPane = new GridPane();
		buttonFlowPane = new FlowPane();
		
		// Setup Labels of inputFieldsPane 
		searchafmLbl = new Label("Αναζήτηση Πελάτη βάση του ΑΦΜ: ");
		searchidLbl = new Label("Αναζήτηση πελάτη βάση του Αριθμού Ταυτότητας:");
		
		idLbl = new Label("Αριθμός Ταυτότητας: ");
		afmLbl = new Label("ΑΦΜ: ");
		fullNameLbl = new Label("Ονοματεπώνυμο: ");
		adrrLbl = new Label("Διεύθυνση: ");
		phoneLbl = new Label("Τηλέφωνο: ");
		emailLbl = new Label("Email: ");
		occLbl = new Label("Ιδιότητα:");
		newLbl = new Label("Στοιχεία Νέου Πελάτη:");
		
		// Setup text Fields of inputFieldsPane 
		searchFieldafm = new TextField();
		searchFieldid = new TextField();
		
		searchFieldid.setPromptText("Αριθμός Ταυτότητας");
		searchFieldafm.setPromptText("ΑΦΜ");
		
		idField = new TextField();
		afmField= new TextField();
		fullNameField= new TextField();
		occField= new TextField();
		addrField= new TextField();
		phoneField= new TextField();
		emailField= new TextField();
		
		
		// Setup Buttons of GridPane.
        newBtn = new Button("Καταχώρηση Νέου Πελάτη");
        refreshBtn = new Button("Τροποποίηση");
        deleteBtn = new Button("Διαγραφή");
        backBtn = new Button("Επιστροφή");
        searchafmBtn = new Button("Αναζήτηση");
        searchidBtn = new Button("Αναζήτηση");
        
     // create objectives
        inputFieldsPane = new GridPane();
        clientTableView = new TableView<>();
        
        // customize flowPane
        // add buttons on flowPane
        buttonFlowPane.setHgap(10);
        buttonFlowPane.setAlignment(Pos.BOTTOM_CENTER);
        
		buttonFlowPane.getChildren().add(newBtn);
		buttonFlowPane.getChildren().add(refreshBtn);
		buttonFlowPane.getChildren().add(deleteBtn);
		buttonFlowPane.getChildren().add(backBtn);
        
        
		// manage of inputFieldsPane
		
		inputFieldsPane.setAlignment(Pos.TOP_RIGHT);
		inputFieldsPane.setVgap(10);
		inputFieldsPane.setHgap(10);
		
		inputFieldsPane.add(searchafmLbl, 0, 0);
        inputFieldsPane.add(searchFieldafm, 1, 0);
        inputFieldsPane.add(searchafmBtn, 0, 1);
        
        inputFieldsPane.add(searchidLbl, 0, 2);
        inputFieldsPane.add(searchFieldid, 1, 2);
        inputFieldsPane.add(searchidBtn, 0, 3);


        
        
        
        inputFieldsPane.add(newLbl, 0, 4);
        
        inputFieldsPane.add(idLbl, 0, 5);
        inputFieldsPane.add(idField, 1, 5);
        
        inputFieldsPane.add(afmLbl, 0, 6);
        inputFieldsPane.add(afmField, 1, 6);
        
        inputFieldsPane.add(fullNameLbl, 0, 7);
        inputFieldsPane.add(fullNameField, 1, 7);
        
        inputFieldsPane.add(occLbl, 0, 8);
      	inputFieldsPane.add(occField, 1, 8);
        
       inputFieldsPane.add(adrrLbl, 0, 9);
       inputFieldsPane.add(addrField, 1, 9);
        
        inputFieldsPane.add(phoneLbl, 0, 10);
        inputFieldsPane.add(phoneField, 1, 10);
        
       inputFieldsPane.add(emailLbl, 0, 11);
        inputFieldsPane.add(emailField, 1, 11);
        
        
        
        
        
        
        
        
        
        
        
        
		
        
     // manage rootGridPane
    	//Gaps
        rootGridPane.setVgap(10);
        rootGridPane.setHgap(10);
     // set inputFieldsPane on rootGridPane
        rootGridPane.add(inputFieldsPane, 1, 0);
     // set tableView on rootGridPane
        rootGridPane.add(clientTableView, 0, 0);
     // set buttonFlowPane on rootGridPane
        rootGridPane.add(buttonFlowPane, 0, 1);
        rootGridPane.add(backBtn, 1, 1);
        
        newBtn.setOnMouseClicked(this);
		refreshBtn.setOnMouseClicked(this);
		deleteBtn.setOnMouseClicked(this);
		backBtn.setOnMouseClicked(this);
		clientTableView.setOnMouseClicked(this);
		searchafmBtn.setOnMouseClicked(this);
		searchidBtn.setOnMouseClicked(this);
		
		// customize TableView
		
        // first column
        
        TableColumn<Client, String> IDColumn = new TableColumn<>("Αριθμός Ταυτότητας");
        // On the next line , i put "ID" because in Client class our field for number id is ID.
        IDColumn.setCellValueFactory(new PropertyValueFactory <>("ID"));
        clientTableView.getColumns().add(IDColumn);	
		
        // Second column
        
        TableColumn<Client, String> afmColumn = new TableColumn<>("Α.Φ.Μ");
        // On the next line , i put "ID" because in Client class our field for number afm is AFM.
        afmColumn.setCellValueFactory(new PropertyValueFactory <>("AFM"));
        clientTableView.getColumns().add(afmColumn);	
        
        
        // Third column
        
        TableColumn<Client, String> FullNameColumn = new TableColumn<>("Ονοματεπώνυμο");
        // On the next line , i put "Full Name" because in Client class our field for full name is FullName.
        FullNameColumn.setCellValueFactory(new PropertyValueFactory <>("FullName"));
        clientTableView.getColumns().add(FullNameColumn);	
        
        // Fourth Column
        TableColumn<Client, String> OccColumn = new TableColumn<>("Ιδιότητα");
        // On the next line , i put "Full Name" because in Client class our field for occupation is occupation.
        OccColumn.setCellValueFactory(new PropertyValueFactory <>("Occupation"));
        clientTableView.getColumns().add(OccColumn);	
        
        //fifth Column
        TableColumn<Client, String> AddrColumn = new TableColumn<>("Διεύθυνση");
        // On the next line , i put "Full Name" because in Client class our field for Address is Address.
        AddrColumn.setCellValueFactory(new PropertyValueFactory <>("Address"));
        clientTableView.getColumns().add(AddrColumn);
        
        // sixth Column
        TableColumn<Client, String> PhoneColumn = new TableColumn<>("Τηλέφωνο");
        // On the next line , i put "Full Name" because in Client class our field for number Phone is Phone.
        PhoneColumn.setCellValueFactory(new PropertyValueFactory <>("Phone"));
        clientTableView.getColumns().add(PhoneColumn);
        
        //seventh Column 
        TableColumn<Client, String> emailColumn = new TableColumn<>("Email");
        // On the next line , i put "Full Name" because in Client class our field for email Phone is email.
        emailColumn.setCellValueFactory(new PropertyValueFactory <>("Email"));
        clientTableView.getColumns().add(emailColumn);
        
        
        
       
        
        
        
        
        
		
		
		
		
		
	}

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	// We call Abstract method from SceneCretor Class because we want to create a new scene (HERE WE CREATE OUR CLIENTS SCENE).
	
	@Override
	Scene createScene() {
		
		return  new Scene(rootGridPane , width , height);
	}
	
	// Method for Functionality of our buttons
	@Override
	public void handle(MouseEvent event) {
		
		// If button Back get clicked ...
    	if(event.getSource() == backBtn) {
            App.primaryStage.setScene(App.mainScene);
            App.primaryStage.setTitle("Κατάστημα Παροχής Τηλεπικοινωνιακών Υπηρεσιών");
        }  
    	
		
    	
    	
    	
    	// if button new get clicked
    	if(event.getSource() == newBtn) {
    		
    		
    	
    
    		
    		
    	if(!(afmField.getText().isEmpty())) {
    		// make sure that afm is a number
    		try {
    			
    			// convert afm textfield from string to int
    			
                 AFM= Long.parseLong(afmField.getText());
               
                
                
                
                
                }catch(IllegalArgumentException e) {

                    Alert alertType = new Alert(Alert.AlertType.ERROR);
                    alertType.setTitle("Invalid value");
                    alertType.setContentText("The value that you gave me for AFM is not a number , try again");
                    alertType.show();
                }
    	
    		
    		if (afmField.getText().length()!=9) {
                
               	
               	
           		Alert alertType = new Alert(Alert.AlertType.ERROR);
           		alertType.setTitle("Invalid value");
           		alertType.setContentText("afm number must contain 9 digits , try again");
           		alertType.show();
           	
           		}
    		  
    	}
    		
    		
    		String ID = idField.getText();
  
    		String FullName = fullNameField.getText();
    		String Occupation = occField.getText();
    		
    		// check inputs for Occupation field
    		
    	if(!(occField.getText().isEmpty())) {	
    		if(!(occField.getText().equals("ιδιώτης")||occField.getText().equals("φοιτητής")||occField.getText().equals("επαγγελματίας")||occField.getText().equals("ΕΠΑΓΓΕΛΜΑΤΙΑΣ")||occField.getText().equals("επαγγελματιας")||occField.getText().equals("φοιτητης")||occField.getText().equals("ΦΟΙΤΗΤΗΣ")||occField.getText().equals("ΙΔΙΩΤΗΣ")||occField.getText().equals("ιδιωτης"))) {
    			Alert alertType = new Alert(Alert.AlertType.ERROR);
                alertType.setTitle("Invalid value");
                alertType.setContentText("Valid inputs are:ιδιώτης/φοιτητής/επαγγελματίας OR ΙΔΙΩΤΗΣ/ΦΟΙΤΗΤΗΣ/ΕΠΑΓΓΕΛΜΑΤΙΑΣ");
                alertType.show();
    		}
    	}
    		
    		String Address = addrField.getText();
    		
    		 Email = emailField.getText();
    		 
    		 
    	     
            
            // Use try-catch because we want to check that the user's input going to be a number.
            if(!(phoneField.getText().isEmpty())) {   
               try {

                Phone = Long.parseLong(phoneField.getText());
               
               

               

               }catch(IllegalArgumentException e) {

                   Alert alertType = new Alert(Alert.AlertType.ERROR);
                   alertType.setTitle("Invalid value");
                   alertType.setContentText("Phone input is not a number, try again.");
                   alertType.show();
               }
            } 
               
               // check if id is already exist
               int temp=0;
               for (int i = 0; i < idList.size(); i++) {
            	   if(idField.getText().equals(idList.get(i))) {
            		   temp=1;
            		   break;
            	   }
               }
               // if id is already exist , warning
               if(temp==1) {

             		Alert alertType = new Alert(Alert.AlertType.ERROR);
             		alertType.setTitle("Invalid value");
             		alertType.setContentText("This id already exists.");
             		alertType.show();
             	
              }
               // check if afm is already exist
               int temp2=0;
               for (int i = 0; i < afmsList.size(); i++) {
            	   if(AFM == afmsList.get(i)) {
            		   temp2=1;
            		   break;
            	   }
               }
               
            // if afm is already exist , warning
               if(temp2==1) {

              		Alert alertType = new Alert(Alert.AlertType.ERROR);
              		alertType.setTitle("Invalid value");
              		alertType.setContentText("This AFM already exists.");
              		alertType.show();
              	
               }
               
               // check phone length
              if(!(phoneField.getText().isEmpty())) { 			
               	if (phoneField.getText().length()!=10) {
               
               	
               	
               		Alert alertType = new Alert(Alert.AlertType.ERROR);
               		alertType.setTitle("Invalid value");
               		alertType.setContentText("Phone number must contain 10 digits , try again");
               		alertType.show();
               	
               		}
              }
               	// check before create a new client all fields are filled.
                   if (idField.getText().isEmpty()||emailField.getText().isEmpty() || fullNameField.getText().isEmpty() || phoneField.getText().isEmpty()){
               
                   	Alert alertType = new Alert(Alert.AlertType.ERROR);
               		alertType.setTitle("Invalid value");
               		alertType.setContentText("Before adding a new client you have to fill all fields , Please try again");
               		alertType.show();
               
                   }
               if ((!(emailField.getText().isEmpty() || fullNameField.getText().isEmpty() || phoneField.getText().isEmpty() || phoneField.getText().length()!=10 || idField.getText().isEmpty() || afmField.getText().isEmpty() || occField.getText().isEmpty() || addrField.getText().isEmpty() || afmField.getText().length()!=9))&& (occField.getText().equals("ιδιώτης")|| occField.getText().equals("φοιτητής")||occField.getText().equals("επαγγελματίας")||occField.getText().equals("ΕΠΑΓΓΕΛΜΑΤΙΑΣ")||occField.getText().equals("επαγγελματιας")||occField.getText().equals("φοιτητης")||occField.getText().equals("ΦΟΙΤΗΤΗΣ")||occField.getText().equals("ΙΔΙΩΤΗΣ")||occField.getText().equals("ιδιωτης"))&&(temp==0 && temp2==0)){
                  	//call createClient method to create our object

            	   createClient(ID, AFM, FullName,  Occupation, Address, Phone, Email);
            	   idList.add(ID);
            	   afmsList.add(AFM);
               }
               
    		
    		
		
		// sync our Table
				OurTableSync();
				
				// clear our fields 
				clearTextFields();
		
    	}
    	
    	
    	// if button delete get clicked
    	if(event.getSource() == deleteBtn) {
           
    	
            
           
    		
    	deleteClient(fullNameField.getText());
		// sync our Table
		OurTableSync();
		
		// clear our fields 
		clearTextFields();
    		
    		
    		
        }  
		
    	 if (event.getSource() == clientTableView) {
    			//take the item that we clicked on it
    			Client selectedClient = clientTableView.getSelectionModel().getSelectedItem();
    			//if this item is not null , then ...
    	        if (selectedClient != null) {
    	        	fullNameField.setText(selectedClient.getFullName());
    	        	occField.setText(selectedClient.getOccupation());
    	        	emailField.setText(selectedClient.getEmail());
    	        	addrField.setText(selectedClient.getAddress());
    	        	phoneField.setText(Long.toString(selectedClient.getPhone()));
    	        	
    	        	
    	        	
    	        	
    	        }
    	    }
		
    	// if button refresh get clicked
     	if(event.getSource() == refreshBtn) {
     		
     
     		
  		  
    		
  
    		String FullName = fullNameField.getText();
    		
    		String Occupation = occField.getText();
    		
    		String Address = addrField.getText();
    		
    		String ID = idField.getText();
    		
    		 Email = emailField.getText();
     		
    		 
    		 if(!(phoneField.getText().isEmpty())) {
    	     try {

                 Phone = Long.parseLong(phoneField.getText());
                
                

                

                }catch(IllegalArgumentException e) {

                    Alert alertType = new Alert(Alert.AlertType.ERROR);
                    alertType.setTitle("Invalid value");
                    alertType.setContentText("The value that you gave me for phone is not a number , try again");
                    alertType.show();
                }
                
                
                
                
                
                
                			
                	if (phoneField.getText().length()!=10) {
                
                	
                	
                		Alert alertType = new Alert(Alert.AlertType.ERROR);
                		alertType.setTitle("Invalid value");
                		alertType.setContentText("Phone number must contains 10 digits , try again");
                		alertType.show();
                	
                		}
    		 }
                	// cant change afmField
                	if(! (afmField.getText().isEmpty())) {
                        
                       	
                       
                   		Alert alertType = new Alert(Alert.AlertType.ERROR);
                   		alertType.setTitle("Invalid value");
                   		alertType.setContentText("AFM number can not change , All other changes were successful .");
                   		alertType.show();
                   	
                   		}
                		
                		// cant change id field	
                	
                		if(! (idField.getText().isEmpty())) {
                        
                       	
                       	
                   		Alert alertType = new Alert(Alert.AlertType.ERROR);
                   		alertType.setTitle("Invalid value");
                   		alertType.setContentText("ID number can not change , All other changes were successful .");
                   		alertType.show();
                   	
                   		}
               
                   	
                   	// check before REFRESH a  client all fields are filled.
                       if ((emailField.getText().isEmpty() || fullNameField.getText().isEmpty() || phoneField.getText().isEmpty())) {
                   
                       	Alert alertType = new Alert(Alert.AlertType.ERROR);
                   		alertType.setTitle("Invalid value");
                   		alertType.setContentText("Before REFRESH a  client you have to fill all fields , Please try again");
                   		alertType.show();
                   
                       }
                       
                   if (!(emailField.getText().isEmpty() || fullNameField.getText().isEmpty() || phoneField.getText().isEmpty()   || occField.getText().isEmpty() || addrField.getText().isEmpty())) {
                	
                	   // call method for refreshing
               		refreshClients(ID, AFM, FullName,  Occupation, Address, Phone, Email);
               		
               	// sync our Table
             		OurTableSync();
             		
             		// clear our fields 
             		clearTextFields();

                   }
                   }
     		
               	// if button Search for afm get Clicked
                   
               	if(event.getSource() == searchafmBtn) {
               		
               		if(searchFieldafm.getText().isEmpty()) {
    	    			
   	    			 Alert alertType = new Alert(Alert.AlertType.ERROR);
   		               alertType.setTitle("Error!");
   		               alertType.setContentText("You can't search  by leaving empty search field. Fill the search field. Please ,  try again");
   		               alertType.show();	
   	    			
   	    		}
               		else
               		{
                       long afm = Long.parseLong(searchFieldafm.getText());
                       OurTableSync();
                       for(Client b: clientList)
                       {
                           if(b.getAFM()!=afm)
                               {
                                   clientTableView.getItems().remove(b);

                               }
                       }
                       }
               	}
     		
     		
             // if button Search for id get Clicked
                
            	if(event.getSource() == searchidBtn) {
            		if(searchFieldid.getText().isEmpty()) {
    	    			
      	    			 Alert alertType = new Alert(Alert.AlertType.ERROR);
      		               alertType.setTitle("Error!");
      		               alertType.setContentText("You can't search  by leaving empty search field. Fill the search field. Please ,  try again");
      		               alertType.show();	
      	    			
      	    		}
            		else {
                    String id = searchFieldid.getText();
                    OurTableSync();
                    for(Client b: clientList)
                    {
                        if(!(b.getID().equals(id)))
                            {
                                clientTableView.getItems().remove(b);

                            }
                    }
            	}
     		
            	}
     		
     		
         
		
		
		
		
		
		
		
		
		
	}

	
// ALL METHODS THAT WE GONNA USE
	
	//Method For creation item with Plan Type
	
		public void createClient(String ID, long AFM, String FullName, String Occupation, String Address, long Phone, String Email) {
	       // create Item named a
			Client b = new Client(ID, AFM, FullName, Occupation ,Address , Phone , Email );
	        // we add item a to our list
			clientList.add(b);
	    }
	
		// method for deleting a client
  		public void deleteClient(String name) {
  			// SEARCH ON LIST FOR OUR COMPANY NAME
  	        for (int i = 0; i < clientList.size(); i++) {
  	        	// If we find the name , we delete it.
  	            if (clientList.get(i).getFullName().equals(name)) {
  	            	clientList.remove(i);
  	                break;
  	            }
  	        }
  	    }
	
  	// method for synchronization our tableView
  		public void OurTableSync() {  
  	        List<Client> items = clientTableView.getItems();
  	        items.clear();
  	        for (Client b : clientList) {
  	            if (b instanceof Client) {
  	                items.add((Client) b);
  	            }
  	        }
  	    }
	
  		
  		
  	// method for Refreshing our clients
  		public void refreshClients(String ID, long AFM, String FullName, String Occupation, String Address, long Phone, String Email) {
  	        for (Client b : clientList) {
  	        	
  	            
  	            //change whatever we want except afm and id
  	            	
  	            	
  	            		b.setAddress(Address);
  	            		b.setEmail(Email);
  	            		b.setFullName(FullName);
  	            		b.setOccupation(Occupation);
  	            		b.setPhone(Phone);
  	            		
  	  	              
  	            	
  	          
  	            
  	        }
  	    }
  		
  		
  		
	
		// METHOD FOR KEEP CLEAR OUR FIELDS.
  		public void clearTextFields() {
  	        idField.setText("");
  	        phoneField.setText("");
  	        afmField.setText("");
  	        emailField.setText("");
  	        fullNameField.setText("");
  	        addrField.setText("");
  	        occField.setText("");
  		
  		}
}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

