// TelecommunicationCompany class




// TelecommunicationCompany class




package gui.work;

public class TelecommunicationCompany {

// fields

private String Pass;
private String Cname;
private long Phone;
private String Email;

// SETTERS & GETTERS 
public String getPass() {
    return Pass;
}
public void setPass(String pass) {
    Pass = pass;
}
public String getCname() {
    return Cname;
}
public void setCname(String cname) {
    Cname = cname;
}
public long getPhone() {
    return Phone;
}
public void setPhone(long phone) {
    Phone = phone;
}
public String getEmail() {
    return Email;
}
public void setEmail(String email) {
    Email = email;
}

// CONSTRACTOR 

public TelecommunicationCompany(String pass, String cname, long phone, String email) {
    super();
    Pass = pass;
    Cname = cname;
    Phone = phone;
    Email = email;
}



}