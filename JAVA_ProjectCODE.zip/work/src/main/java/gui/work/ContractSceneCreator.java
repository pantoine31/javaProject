package gui.work;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.lang.reflect.Array;

import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;

//Scene of Clients
//This scene shows up when we click contractBtn

public class ContractSceneCreator extends SceneCreator implements EventHandler<MouseEvent> {
	private static long Phone;
	private static long AFM;
	private static long Duration;
	private static long Date;
	private static  String Pass;
	private static double AfterCost;
	private static double CancelCost;
	private static double Discount;
	private static boolean Active;
	private static  String thisName ;
	static boolean check;
	

	// TableView of Contract Scene (TableView is on GridPane)
	TableView<Contract> contractTableView;
	List<Contract>ContractList = new ArrayList<Contract>();
	List<Long>PhonesList = new ArrayList<Long>();


	// Contract Scene Flow Pane (root node)   
		FlowPane buttonFlowPane; 
		
		// Contract Scene Grid Pane
		GridPane rootGridPane , inputFieldsPane,comboPane;
		
		// Buttons of Contract Scene
		Button newBtn  , deleteBtn , searchBtn , searchPhoneBtn , backBtn;
		
		
		// Labels of Contract Scene (these labels are on inputFieldsPane)
		Label payMethod ,gapsLbl1 , gapsLbl2 , gapsLbl3 , passLbl , phoneLbl , afmLbl , searchLbl, newLbl ,  planLbl , dateLbl , durLbl , actLbl , ccLbl , typeLbl,ActivityLbl , searchPhoneLbl;
		
		// TextFields of Client Scene (these labels are on inputFieldsPane)
		TextField  payMethodField , phoneField ,afmField, passField , planField , durField , actField , typeField , dateField , searchPhoneField ;
		
		  ComboBox<String> combo1 = new ComboBox<String>();
		
	
	
	// Constructor from superclass
	public ContractSceneCreator(double width, double height) {
		super(width, height);
		
		
		// create objectives
				rootGridPane = new GridPane();
				buttonFlowPane = new FlowPane();
		
				
				
				// Setup Labels of inputFieldsPane 
				ActivityLbl = new Label("Ενεργό Συμβόλαιο:");
				afmLbl = new Label("ΑΦΜ:");
				typeLbl = new Label("Τύπος Λογαριασμού (Έντυπος/Ηλεκτρονικός):");
				actLbl = new Label("Κατάσταση Συμβολαίου: ");
				durLbl = new Label("Διάρκεια Συμβολαίου: ");
		        dateLbl = new Label("Ημερομηνίας Έναρξης Συμβολαίου: ");
				planLbl = new Label("Πρόγραμμα (Mobile/Landline): ");
		        passLbl = new Label("Κωδικός: ");
		        phoneLbl = new Label("Τηλέφωνο: ");
		        searchLbl = new Label("Αναζήτηση βάση τύπου συμβολαίου: ");
		        newLbl = new Label("Στοιχεία Νέου συμβολαίου:");
		        gapsLbl1 = new Label("-----");
		        gapsLbl2= new Label("-----");
		        gapsLbl3= new Label("-----");
		        payMethod = new Label("Τρόπος Πληρωμής(Μετρητά/Πιστωτική Κάρτα)");
		        searchPhoneLbl = new Label("Αναζήτηση βάση αριθμού συμβολαίου:");
		        
		        
		     // Setup text Fields of inputFieldsPane 
		       afmField = new TextField();
		        passField = new TextField();
		        phoneField = new TextField();
		        typeField = new TextField();
		        actField = new TextField();
		        durField = new TextField();
		        dateField = new TextField();
		        planField = new TextField();
		        payMethodField = new TextField();
		        actField = new TextField();
		        searchPhoneField = new TextField();
		        
		        
		       
		        // non-editable field
		        passField.setEditable(false);
		        actField.setEditable(false);

		        // Setup Buttons of GridPane.
		        newBtn = new Button("Δημιουργία νέου συμβολαίου");
		        deleteBtn = new Button("Ακύρωση συμβολαίου");
		        backBtn = new Button("Επιστροφή");
		        searchBtn = new Button("Αναζήτηση");
		        searchPhoneBtn = new Button("Αναζήτηση");
		        
		     // create objectives
		        inputFieldsPane = new GridPane();
		        contractTableView = new TableView<>();
		
		        
		      
				
				//set up combo box
		     
		        
		       combo1.getItems().addAll("Landline" , "LANDLINE" , "landline" , "MOBILE" , "mobile" , "Mobile"); 
		       combo1.setPromptText("Επιλογές");
		       
		       
		       
		       
		        
	
				
		        
		     // customize flowPane
		        // add buttons on flowPane
		        buttonFlowPane.setHgap(12);
		        buttonFlowPane.setAlignment(Pos.BOTTOM_CENTER);
		        
				buttonFlowPane.getChildren().add(newBtn);
				buttonFlowPane.getChildren().add(deleteBtn);
				
				inputFieldsPane.setAlignment(Pos.TOP_RIGHT);
		        inputFieldsPane.setVgap(10);
		        inputFieldsPane.setHgap(10);
		        
		        inputFieldsPane.add(newLbl, 0, 0);
		
		        inputFieldsPane.add(passLbl, 0, 1);
		        inputFieldsPane.add(passField, 1, 1);
		        
		        inputFieldsPane.add(afmLbl, 0, 2);
		        inputFieldsPane.add(afmField, 1, 2);
		        
		        
		        inputFieldsPane.add(phoneLbl, 0, 3);
		        inputFieldsPane.add(phoneField, 1, 3);
		        
		        
		        inputFieldsPane.add(typeLbl, 0, 4);
		        inputFieldsPane.add(typeField, 1, 4);
		  
		        
		        inputFieldsPane.add(dateLbl, 0, 5);
		        inputFieldsPane.add(dateField, 1, 5);
		        
		        inputFieldsPane.add(durLbl, 0, 6);
		        inputFieldsPane.add(durField, 1, 6);
		        
		        inputFieldsPane.add(payMethod, 0, 7);
		        inputFieldsPane.add(payMethodField, 1, 7);
		        
		        inputFieldsPane.add(planLbl, 0, 8);
		        inputFieldsPane.add(planField, 1, 8);
		        
		        inputFieldsPane.add(actLbl, 0, 9);
		        inputFieldsPane.add(actField, 1,9);
		        
		        
		        inputFieldsPane.add(searchLbl, 0, 12);
		        inputFieldsPane.add(combo1, 0, 13);
		        inputFieldsPane.add(searchBtn, 1, 13);
		        
		        
		        inputFieldsPane.add(searchPhoneLbl, 0, 14);
		        inputFieldsPane.add(searchPhoneField, 0, 15);
		        inputFieldsPane.add(searchPhoneBtn, 1, 15);
		     // manage rootGridPane
	        	//Gaps
	        rootGridPane.setVgap(20);
	        rootGridPane.setHgap(20);
	        
	      
	        // set inputFieldsPane on rootGridPane
	        rootGridPane.add(inputFieldsPane, 1, 0);
	     // set tableView on rootGridPane
	        rootGridPane.add(contractTableView, 0, 0);
	     // set buttonFlowPane on rootGridPane
	        rootGridPane.add(buttonFlowPane, 0, 1);
	        rootGridPane.add(backBtn, 1, 1);
	        
	        
	        // customize TableView
	        // first column
	        
	        TableColumn<Contract, String> passColumn = new TableColumn<>("Κωδικός");
	       
	        passColumn.setCellValueFactory(new PropertyValueFactory <>("Pass"));
	        passColumn.setPrefWidth(125);
	        contractTableView.getColumns().add(passColumn);
	        
	        // second column
	        TableColumn<Contract, String> phoneColumn = new TableColumn<>("Τηλέφωνο");
		    
		        phoneColumn.setCellValueFactory(new PropertyValueFactory<>("Phone"));
		        phoneColumn.setPrefWidth(125);
		        contractTableView.getColumns().add(phoneColumn);

	      
	        // third column
		     TableColumn<Contract, String> afmColumn = new TableColumn<>("AFM");
			
			       afmColumn.setCellValueFactory(new PropertyValueFactory<>("AFM"));
			       afmColumn.setPrefWidth(125);
			      contractTableView.getColumns().add(afmColumn);
					
		      
	        
	       // forth column 
			TableColumn<Contract, String> nameColumn = new TableColumn<>("Τύπος Λογαριασμού");
	
			    nameColumn.setCellValueFactory(new PropertyValueFactory<>("Type"));
			    nameColumn.setPrefWidth(125);
			    contractTableView.getColumns().add(nameColumn);

			
		   // fifth column 
			TableColumn<Contract, String> planColumn = new TableColumn<>("Πρόγραμμα");
		  
				 planColumn.setCellValueFactory(new PropertyValueFactory<>("Plan"));
				 planColumn.setPrefWidth(125);
				 contractTableView.getColumns().add(planColumn);

	        
			// sixth column 
			TableColumn<Contract, String> dateColumn = new TableColumn<>("Ημερομηνία Έναρξης");
			
				dateColumn.setCellValueFactory(new PropertyValueFactory<>("Date"));
				dateColumn.setPrefWidth(125);
				contractTableView.getColumns().add(dateColumn);

	        
			// seventh column 
			TableColumn<Contract, String> durationColumn = new TableColumn<>("Διάρκεια Συμβολαίου");
			
				durationColumn.setCellValueFactory(new PropertyValueFactory<>("Duration"));
				durationColumn.setPrefWidth(125);
				contractTableView.getColumns().add(durationColumn);
	        
	        
		  // seventh column 
		  TableColumn<Contract, String> paymethodColumn = new TableColumn<>("Τρόπος Πληρωμής");
		 
			  paymethodColumn.setCellValueFactory(new PropertyValueFactory<>("PayMethod"));
			  paymethodColumn.setPrefWidth(125);
			  contractTableView.getColumns().add(paymethodColumn);        
	        
	        
		// eighth column 
		TableColumn<Contract, String> activeColumn = new TableColumn<>("Ενεργό Συμβόλαιο");
		
			activeColumn.setCellValueFactory(new PropertyValueFactory<>("Active"));
			activeColumn.setPrefWidth(125);
			contractTableView.getColumns().add(activeColumn);
			
	           
		// ninth column 
		TableColumn<Contract, String> ccColumn = new TableColumn<>("Κόστος Ακύρωσης");
		
			ccColumn.setCellValueFactory(new PropertyValueFactory<>("CancelCost"));
			ccColumn.setPrefWidth(125);
			 contractTableView.getColumns().add(ccColumn);        
			           
		// tenth column 
		TableColumn<Contract, String> disColumn = new TableColumn<>("Έκπτωση");
		
			disColumn.setCellValueFactory(new PropertyValueFactory<>("Discount"));
			disColumn.setPrefWidth(125);
			contractTableView.getColumns().add(disColumn);      
	        
	        
	        
	    // eleventh column 
		TableColumn<Contract, String> costColumn = new TableColumn<>("Κόστος Πληρωμής");
		
			costColumn.setCellValueFactory(new PropertyValueFactory<>("AfterCost"));
			costColumn.setPrefWidth(125);
			contractTableView.getColumns().add(costColumn);      
	        
	        
	        
	        
	        
	        
	        
	        
	 
	        
		
		 newBtn.setOnMouseClicked(this);
		 deleteBtn.setOnMouseClicked(this);
		 searchBtn.setOnMouseClicked(this);
	     backBtn.setOnMouseClicked(this);
	     searchPhoneBtn.setOnMouseClicked(this);
	     contractTableView.setOnMouseClicked(this);
	     
	     
	     contractTableView.setEditable(true);
	     
		
	}

	
	
	
	// We call Abstract method from SceneCretor Class because we want to create a new scene (HERE WE CREATE OUR CONTRACT SCENE).
	
	@Override
	Scene createScene() {
		return new Scene(rootGridPane , width , height);
		
	}
	

	@Override
	public void handle(MouseEvent event){
		int phonelisttrack=0;
		// If button Back get clicked ...
    	if(event.getSource() == backBtn) {
            App.primaryStage.setScene(App.mainScene);
            App.primaryStage.setTitle("Κατάστημα Παροχής Τηλεπικοινωνιακών Υπηρεσιών");
        }  
		
    	
    	 // if we click on the table view	
    	if (event.getSource() == contractTableView) {
    		//take the item that we clicked on it
    		Contract selectedContract = contractTableView.getSelectionModel().getSelectedItem();
    		//if this item is not null , then fill textFields
    		//akurwsh ΘΕΛΩ ΧΕΛΠ ΔΕΝ ΤΟ ΠΙΑΝΕΙ
    	    if (selectedContract != null) {
    	    	
    	    	
    	    	
    	    	
    	    	
    	    	
    	    	
    	    	
    	    	
    	    	
    	    	
    	    	
    	    	payMethodField.setText(selectedContract.getPayMethod());
    	    	phoneField.setText(Long.toString(selectedContract.getPhone()));
    	    	afmField.setText(Long.toString( selectedContract.getAFM()));
    	    	passField.setText(selectedContract.getPass());
    	    	planField.setText(selectedContract.getPlan()); 
    	    	durField.setText(Long.toString(selectedContract.getDuration())); 
    	    	actField.setText(Boolean.toString(selectedContract.isActive())); 
    	    	typeField.setText(selectedContract.getType());
    	    	dateField.setText(Long.toString(selectedContract.getDate())); 
    	    	 
    			
    	    	
    	    	
    	    	actField.setEditable(true);
    	    	
    	    	
    	       
    	        // take company's name to compare on refresh method
    	       thisName =	selectedContract.getPass();
    	       
    	       // TAKE VALUE OF ACTIVE OR NOT CONTRTACT
    	       check = selectedContract.isActive();
    	       
    	       
    	       
    	    }
    	}
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	

	
	// if button new get clicked
	if(event.getSource() == newBtn) {
		if( afmField.getText().isEmpty() && phoneField.getText().isEmpty() && typeField.getText().isEmpty() && actField.getText().isEmpty() && durField.getText().isEmpty() &&  dateField.getText().isEmpty() &&  planField.getText().isEmpty() && payMethodField.getText().isEmpty() && searchPhoneField.getText().isEmpty()){
			Alert alertType = new Alert(Alert.AlertType.ERROR);
            alertType.setTitle("Invalid value");
            alertType.setContentText("You can't create a new contract by leaving every field empty!");
            alertType.show();
		}
		else { Active=false;
		String Type = typeField.getText();
		String Plan = planField.getText();
        String PayMethod = payMethodField.getText();
        String Act = actField.getText();
        
        
        
       if(!(PayMethod.equals("Πιστωτική Κάρτα")||PayMethod.equals("ΠΙΣΤΩΤΙΚΗ ΚΑΡΤΑ")||PayMethod.equals("Πιστωτικη Καρτα")||PayMethod.equals("πιστωτικη καρτα")||PayMethod.equals("Μετρητά")||PayMethod.equals("Μετρητα")||PayMethod.equals("ΜΕΤΡΗΤΑ")||PayMethod.equals("μετρητα")||PayMethod.equals("μετρητά"))) {
        	Alert alertType = new Alert(Alert.AlertType.ERROR);
            alertType.setTitle("Invalid value");
            alertType.setContentText("Valid inputs are:Πιστωτική Κάρτα/Μετρητά , try again");
            alertType.show();
        }
        
        if(!(Type.equals("ΗΛΕΚΤΡΟΝΙΚΟΣ")||Type.equals("ηλεκτρονικός")||Type.equals("Ηλεκτρονικός")||Type.equals("Ηλεκτρονικος")||Type.equals("ηλεκτρονικος")||Type.equals("έντυπος")||Type.equals("Έντυπος")||Type.equals("εντυπος")||Type.equals("Εντυπος")||Type.equals("ΕΝΤΥΠΟΣ")||Type.equals("ΈΝΤΥΠΟΣ"))) {
        	  
            	Alert alertType = new Alert(Alert.AlertType.ERROR);
            	alertType.setTitle("Invalid value");
            	alertType.setContentText("Valid inputs are:Ηλεκτρονικός/Έντυπος , try again");
            	alertType.show();
            }
          

		// make sure that afm is a number
		try {
			
			// convert afm textfield from string to int
			AFM= Long.parseLong(afmField.getText());
           
     		

            }catch(IllegalArgumentException e) {
            	Alert alertType = new Alert(Alert.AlertType.ERROR);
                alertType.setTitle("Invalid value");
                alertType.setContentText("The value that you gave me for AFM is not a number , try again");
                alertType.show();
            }
		
		
	if (afmField.getText().length()!=9) {	
          Alert alertType = new Alert(Alert.AlertType.ERROR);
       	  alertType.setTitle("Invalid value");
       	  alertType.setContentText("afm number must contain 9 digits , try again");
       	  alertType.show();
       	
       		}
		  

        // Use try-catch because we want to check that the user's input going to be a number.

		 try {
	       Duration = Long.parseLong(durField.getText());  
		 
		 }catch(IllegalArgumentException e) {

	               Alert alertType = new Alert(Alert.AlertType.ERROR);
	               alertType.setTitle("Invalid value");
	               alertType.setContentText("Duration input is not a number, try again.");
	               alertType.show();
	           }


	        // Use try-catch because we want to check that the user's input going to be a number.

		 try {
			 Date = Long.parseLong(dateField.getText());
		 }catch(IllegalArgumentException e) {
			 Alert alertType = new Alert(Alert.AlertType.ERROR);
			 alertType.setTitle("Invalid value");
			 alertType.setContentText("Date input is not a number, try again.The format should be ddmmyyyy");
		     alertType.show();
		 }
		
		 
		Long expired=null;
		//pairnw tin smrini hmerominia gia na dw an exei lhksei to kathe sumvolaio.
			DateTimeFormatter dtf = DateTimeFormatter.ofPattern("ddMMuuuu");
			  LocalDate localDate = LocalDate.now();
			 String shmera = dtf.format(localDate);
			//sto date elegxos an einai swstos o arithmos psifiwn.
			 if(dateField.getText().length()==8) {
			//elegxos gia to ama einai 12 h 24. an einai to kanw apo px 10112002 se +1 ara 10112003 to antistoixo me 24 mines
			if(Duration==12) {
				  expired = Date + 1; 
				 }
			 else if(Duration==24) {
				  expired = Date +2;
			 }
			 else {
				 Alert alertType = new Alert(Alert.AlertType.ERROR);
				 alertType.setTitle("Invalid value");
				 alertType.setContentText("Duration should be 12 months or 24 months. Please insert 12 or 24.");
			     alertType.show();
			    
			 }
			 }
			 else {
				 if(Duration!=12 && Duration!=24) {
					 Alert alertType = new Alert(Alert.AlertType.ERROR);
					 alertType.setTitle("Invalid value");
					 alertType.setContentText("Duration should be 12 months or 24 months. Please insert 12 or 24.");
				     alertType.show();
				    
				 }
				 Alert alertType = new Alert(Alert.AlertType.ERROR);
				 alertType.setTitle("Invalid value");
				 alertType.setContentText("Date input should be 8 numbers. try again.The format should be ddmmyyyy ex. 02062020");
			     alertType.show();
			}
			 //me tin thereszeroindate vlepw an kati paei lathos me tin date wste na min kanw client
			int TheresZeroInDate=0;
			Long Today = Long.parseLong(shmera);
			int YearToday=(int) (Today%10000);//pairnw tin shmerini xronologia
			int YearContract=(int)(expired % 10000);//pairnw tin tou sumbolaiou otan ligei xronologia
			int TodayMonths=0;
			int expiredMonths=0;
			int TodayDay=0;
			int expiredDay=0;
			String TodayConv = String.valueOf(Today);//ta kanw string wste na mpoun stous katw pinakes
			String expiredConv = String.valueOf(expired);
			char[] digitsToday = TodayConv.toCharArray();//xrisimopoiw tous pinakes gia na exw tin dunatotita na parw akrivws opoia psifia thelw.
			char[] digitsExpired = expiredConv.toCharArray();
		
			if(expired!=null) {
				//an kapoios valei 000122000 gia px, tha to dexthei ws 8psifio alla meta logw tis long tha to metatrepsei se 122000 kai etsi kseroume oti kapoios evale mhdenika gia date.
				if(Date<122000 || Date>=32000000) {
						 Alert alertType = new Alert(Alert.AlertType.ERROR);
						 alertType.setTitle("Invalid value");
						 alertType.setContentText("Day cant be 0 or bigger than 31,try again.The format should be ddmmyyyy ex. 02062020");
						 alertType.show();
						 TheresZeroInDate=1;
				}
			
			if(YearToday<YearContract) {
				Active=true;	
			}
			else if(YearToday==YearContract){
				
				//vazw me 7 se periptwsh pou ksekinaei me 0 px 06052020 giati to text elegxei an einai 8 komple alla meta to kanei convert se 6052020
				if(TodayConv.length()==7 && expiredConv.length()==7 ) {
					
					TodayMonths= Character.getNumericValue(digitsToday[1])*10+Character.getNumericValue(digitsToday[2]);
					 expiredMonths=Character.getNumericValue(digitsExpired[1])*10+Character.getNumericValue(digitsExpired[2]);
					 if(expiredMonths==0||expiredMonths>12) {
						 Alert alertType = new Alert(Alert.AlertType.ERROR);
						 alertType.setTitle("Invalid value");
						 alertType.setContentText("Month cant be 0 or more than 12,try again.The format should be ddmmyyyy ex. 02062020");
						 alertType.show();
						 TheresZeroInDate=1;}
					if(TodayMonths<expiredMonths) {
					 		Active=true;
					 	}
					 else if(TodayMonths==expiredMonths) {
					 		TodayDay=Array.getChar(digitsToday, 0);
					 		expiredDay=Array.getChar(digitsExpired, 0);
					 		
					 		if(TodayDay<expiredDay) {
					 			Active=true;
					 		}
						 
					 	}
				}
				
				else if(TodayConv.length()==8 && expiredConv.length()==7 ) {
					
					TodayMonths=Character.getNumericValue(digitsToday[2])*10+Character.getNumericValue(digitsToday[3]);
					 expiredMonths=Character.getNumericValue(digitsExpired[1])*10+Character.getNumericValue(digitsExpired[2]);
					 if(expiredMonths==0 ||expiredMonths>12) {
						 Alert alertType = new Alert(Alert.AlertType.ERROR);
						 alertType.setTitle("Invalid value");
						 alertType.setContentText("Month cant be 0 or more than 12,try again.The format should be ddmmyyyy ex. 02062020");
						 alertType.show();
						 TheresZeroInDate=1;}
					
					 if(TodayMonths<expiredMonths) {
					 		Active=true;
					 	}
					 else if(TodayMonths==expiredMonths) {
					 		TodayDay=Character.getNumericValue(digitsToday[0])*10+Character.getNumericValue(digitsToday[1]);
					 		expiredDay=Character.getNumericValue(digitsExpired[0]);
					 	
					 		if(TodayDay<expiredDay) {
					 			Active=true;
					 		}
						 
					 }
				}
				else if(TodayConv.length()==7 && expiredConv.length()==8 ) {
					 
					TodayMonths=Character.getNumericValue(digitsToday[1])*10+Character.getNumericValue(digitsToday[2]);
					 expiredMonths=Character.getNumericValue(digitsExpired[2])*10+Character.getNumericValue(digitsExpired[3]);
					 if(expiredMonths==0||expiredMonths>12) {
						 Alert alertType = new Alert(Alert.AlertType.ERROR);
						 alertType.setTitle("Invalid value");
						 alertType.setContentText("Month cant be 0 or more than 12,try again.The format should be ddmmyyyy ex. 02062020");
						 alertType.show();
						 TheresZeroInDate=1;}
					 if(TodayMonths<expiredMonths) {
					 		Active=true;
					 	}
					 else if(TodayMonths==expiredMonths) {
					 		TodayDay=Character.getNumericValue(digitsToday[0]);
					 		expiredDay=Character.getNumericValue(digitsExpired[0])*10+Character.getNumericValue(digitsExpired[1]);
					 		
					 		if(TodayDay<expiredDay) {
					 			Active=true;
					 		}
						 
					 	}
				}
				else if(TodayConv.length()==8 && expiredConv.length()==8 ) {
					 
					TodayMonths=Character.getNumericValue(digitsToday[2])*10+Character.getNumericValue(digitsToday[3]);
					 expiredMonths=Character.getNumericValue(digitsExpired[2])*10+Character.getNumericValue(digitsExpired[3]);
					if(expiredMonths==0||expiredMonths>12) {
						 Alert alertType = new Alert(Alert.AlertType.ERROR);
						 alertType.setTitle("Invalid value");
						 alertType.setContentText("Month cant be 0 or more than 12,try again.The format should be ddmmyyyy ex. 02062020");
						 alertType.show();
						 TheresZeroInDate=1;}
					 if(TodayMonths<expiredMonths) {
					 		Active=true;
					 	}
					 else if(TodayMonths==expiredMonths) {
						 TodayDay=digitsToday[0]*10+digitsToday[1];
					 	expiredDay=digitsExpired[0]*10+digitsExpired[1];
					 		if(TodayDay<expiredDay) {
					 			Active=true;
					 		}
						 
					 	}
				}
			
			}
			
			//an o minas einai px o septembris(9) na exei 30 meres oxi 31 . gia na varesei auto prepei eksarxis na exoume 8 psifia giauto den uparxei if opws panw 
			 expiredMonths=Character.getNumericValue(digitsExpired[2])*10+Character.getNumericValue(digitsExpired[3]);
			 expiredDay=digitsExpired[0]*10+digitsExpired[1];
				if((expiredMonths==4||expiredMonths==6||expiredMonths==9||expiredMonths==11)&&expiredDay==31) {
					Alert alertType = new Alert(Alert.AlertType.ERROR);
					 alertType.setTitle("Invalid value");
					 alertType.setContentText("That month doesnt have more than 30 days.");
					 alertType.show();
					 TheresZeroInDate=1;
				}
				else if(expiredMonths==2&&expiredDay>29) {
					Alert alertType = new Alert(Alert.AlertType.ERROR);
					 alertType.setTitle("Invalid value");
					 alertType.setContentText("That month doesnt have more than 29 days.");
					 alertType.show();
					 TheresZeroInDate=1;
				}

			
			}
		 
        // Use try-catch because we want to check that the user's input going to be a number.
           
          try {

            Phone = Long.parseLong(phoneField.getText());

           }catch(IllegalArgumentException e) {

               Alert alertType = new Alert(Alert.AlertType.ERROR);
               alertType.setTitle("Invalid value");
               alertType.setContentText("Phone input is not a number, try again.");
               alertType.show();
           }
          //gia na dw an vgainei to 6xxxxxxxxx tou phone p1
          long temp = Long.parseLong(phoneField.getText())/1000000000;
         
          
           	if (phoneField.getText().length()!=10 ) {
           		
           		Alert alertType = new Alert(Alert.AlertType.ERROR);
           		alertType.setTitle("Invalid value");
           		alertType.setContentText("Phone number must contain 10 digits , try again");
           		alertType.show();
           	
           		}
           
           	// check before create a new client all fields are filled.
               if(afmField.getText().isEmpty() || phoneField.getText().isEmpty() || typeField.getText().isEmpty() || planField.getText().isEmpty() || dateField.getText().isEmpty() || durField.getText().isEmpty() || payMethod.getText().isEmpty()){
           
               	Alert alertType = new Alert(Alert.AlertType.ERROR);
           		alertType.setTitle("Invalid value");
           		alertType.setContentText("Before adding a new contract you have to fill all fields , Please try again");
           		alertType.show();
           
               }
               
               //to xrhsimopoiw san voithitiki wste na min kanw client an valoun arithmo pou ksekinaei lathos(allazei stis periptwseis tou lathos entry se temp2=1 :D
        		int temp2=0;

               if(planField.getText().equals("Landline")||planField.getText().equals("LANDLINE")||planField.getText().equals("landline")) {
               String Passaki=String.valueOf(Date)+"<"+String.valueOf(AFM)+">"+"Landline";
               Pass=Passaki;
               passField.setText(Pass);
               if( temp!=2) {
            	   Alert alertType = new Alert(Alert.AlertType.ERROR);
              		alertType.setTitle("Invalid value");
              		alertType.setContentText("Valid input: 2xxxxxxxxx , try again");
              		alertType.show();   
             		 temp2=1;

               }
               }
               else if(planField.getText().equals("Mobile")||planField.getText().equals("MOBILE")||planField.getText().equals("mobile")) {
                   String Passaki=String.valueOf(Date)+"<"+String.valueOf(AFM)+">"+"Mobile";
                   Pass=Passaki;
                   passField.setText(Pass);
                   if( temp!=6) {
                	   Alert alertType = new Alert(Alert.AlertType.ERROR);
                  		alertType.setTitle("Invalid value");
                  		alertType.setContentText("Valid input: 6xxxxxxxxx , try again");
                  		alertType.show();
                  		 temp2=1;
                   }
                   }
               else {
            	  	Alert alertType = new Alert(Alert.AlertType.ERROR);
               		alertType.setTitle("Invalid value");
               		alertType.setContentText("Valid inputs are: Landline/Mobile");
               		alertType.show();
               
               }
             //elegxos an uparxei o pelaths
               int ClientExists=0;
               Discount=0.00;
               for(Long i : ClientsSceneCreator.afmsList) {
            	   if(AFM==i) {
            		 //EKPTWSHHHHHH
                 
                    	   for (Client b : ClientsSceneCreator.clientList) {
             	            if(AFM==b.getAFM()) {
              	               	if(b.getOccupation().equals("ΕΠΑΓΓΕΛΜΑΤΙΑΣ")||b.getOccupation().equals("επαγγελματίας")||b.getOccupation().equals("επαγγελματιας")) {
              	               		Discount=0.10;
              	               	}
              	               	else if(b.getOccupation().equals("ΦΟΙΤΗΤΗΣ")||b.getOccupation().equals("φοιτητης")||b.getOccupation().equals("φοιτητής"))
              	               		Discount=0.15;
              	               	else {
              	               		Discount=0.00;
              	               	}
              	               	
              	               if(Plan.equals("LANDLINE")||Plan.equals("Landline")||Plan.equals("landline")) {
              	            	   Discount=Discount+0.08;
              	               }
              	               else{
              	            	   Discount=Discount+0.11;

              	               }
              	               if(PayMethod.equals("Πιστωτική Κάρτα")||PayMethod.equals("ΠΙΣΤΩΤΙΚΗ ΚΑΡΤΑ")||PayMethod.equals("Πιστωτικη Καρτα")||PayMethod.equals("πιστωτικη καρτα")) {
              	            	 Discount=Discount+0.05;
              	               }
              	               if(Type.equals("ΗΛΕΚΤΡΟΝΙΚΟΣ")||Type.equals("ηλεκτρονικός")||Type.equals("Ηλεκτρονικός")||Type.equals("Ηλεκτρονικος")||Type.equals("ηλεκτρονικος")) {
              	            	 Discount=Discount+0.02;
              	               }
              	            }
              	        }
                  //     AfterCost=Cost
                       
                  
            		   ClientExists=1;
            		   break;
            	   }
               }
               
               if(ClientExists==0) {
            	   Alert alertType = new Alert(Alert.AlertType.ERROR);
             		alertType.setTitle("Invalid value");
             		alertType.setContentText("There's no existing client with that afm. Please try again.");
             		alertType.show();
             		
               }
               //Checking if two contracts under the same number exist.
             	//tin xrhsimopoiw gia to createcontract. 
                 int oldcontractexists=0;
                 
               	  OurTableSync();
                     for(Contract b: ContractList)
                     {
                         if(b.getPhone()==Phone)
                             {
                                if(b.isActive()==true) {
                               	 Alert alertType = new Alert(Alert.AlertType.ERROR);
                               		alertType.setTitle("Invalid value");
                               		alertType.setContentText("You can't make a new contract. Your old contract is still active.");
                               		alertType.show();
                               		
                               		oldcontractexists=1;
                                }
                             break;
                             }
                         
                     }
               	  
                	   
                	   
                	   
                	   
                	   
                	   
              if (!(passField.getText().isEmpty() || planField.getText().isEmpty() || phoneField.getText().isEmpty() || phoneField.getText().length()!=10 || temp2==1 || typeField.getText().isEmpty() || afmField.getText().isEmpty() ||  payMethodField.getText().isEmpty() || durField.getText().isEmpty() || afmField.getText().length()!=9||dateField.getText().isEmpty())&&(Duration==12||Duration==24)&&(PayMethod.equals("Πιστωτική Κάρτα")||PayMethod.equals("ΠΙΣΤΩΤΙΚΗ ΚΑΡΤΑ")||PayMethod.equals("Πιστωτικη Καρτα")||PayMethod.equals("πιστωτικη καρτα")||PayMethod.equals("Μετρητά")||PayMethod.equals("Μετρητα")||PayMethod.equals("ΜΕΤΡΗΤΑ")||PayMethod.equals("μετρητα")||PayMethod.equals("μετρητά"))&&(Type.equals("ΗΛΕΚΤΡΟΝΙΚΟΣ")||Type.equals("ηλεκτρονικός")||Type.equals("Ηλεκτρονικός")||Type.equals("Ηλεκτρονικος")||Type.equals("ηλεκτρονικος")||Type.equals("έντυπος")||Type.equals("Έντυπος")||Type.equals("εντυπος")||Type.equals("Εντυπος")||Type.equals("ΕΝΤΥΠΟΣ")||Type.equals("ΈΝΤΥΠΟΣ"))&&TheresZeroInDate!=1&&ClientExists==1&&oldcontractexists==0){
               	//call createClient method to create our object

            	  
				            	 // IF mbCounter > 0 , shmainei oti SIGOURA exoume dimiourghsei plan typoy mobile , ara mporoume na ftiaksoume contract 
				            	if(mobSceneCreator.mobCounter>=0 && ((planField.getText().equals("Mobile")||planField.getText().equals("MOBILE")||planField.getText().equals("mobile")))) {
				         	   
				            		double cost2 = mobSceneCreator.costList.get(mobSceneCreator.mobCounter);
				         			 
						         	 
						         	 
				         			 AfterCost=cost2-cost2*Discount;
				            		
				            		
				            		createContract( Pass, Phone,  AFM,  Plan,  Date,  Duration,  Discount,
				 	  			         PayMethod,  AfterCost,  Type,  CancelCost,  Active);
				         	   
				         	   
				         	   // meiwnw kathe fora ton counter omws epeidh xrisimopoihsa to plan 
				         	   mobSceneCreator.mobCounter=mobSceneCreator.mobCounter-1;
				         	   
				         	   
				            	}
				            	
				            	// IF mobCounter<0 , error
				            	else {
				            		
				            		if((planField.getText().equals("Mobile")||planField.getText().equals("MOBILE")||planField.getText().equals("mobile"))) {
				            		
				            			Alert alertType = new Alert(Alert.AlertType.ERROR);
									 alertType.setTitle("ERROR");
									 alertType.setContentText("There's no mobile plan. To create a mobile contract , create FIRST a mobile plan.");
									 alertType.show();
				            		
            		
            		
            		
            		
				            		}
				            	}
            	
				            	 // IF landCounter > 0 , shmainei oti SIGOURA exoume dimiourghsei plan typoy landline , ara mporoume na ftiaksoume contract 
				            	if( landLinesSceneCreator.landCounter>=0 && (planField.getText().equals("Landline")||planField.getText().equals("LANDLINE")||planField.getText().equals("landline"))) {
				         	  
				            		
				            		   
						         	 double cost2 = landLinesSceneCreator.costList.get(landLinesSceneCreator.landCounter);
				         			 
						         	 
						         	 
				         			 AfterCost=cost2-cost2*Discount;
				            		
				            		createContract( Pass, Phone,  AFM,  Plan,  Date,  Duration,  Discount,
				 	  			         PayMethod,  AfterCost,  Type,  CancelCost,  Active);
				         	   
				            	
				         	   
				         	   
				         	   
				         	   
				         	   
				         	   // meiwnw kathe fora ton counter omws epeidh xrisimopoihsa to plan 
				         	  landLinesSceneCreator.landCounter= landLinesSceneCreator.landCounter-1;
				    
				         			 
				            	}
				            	
				            	// IF mobCounter<0 , error
				            	else {
				            		
				            		if((planField.getText().equals("Landline")||planField.getText().equals("LANDLINE")||planField.getText().equals("landline"))){
				            		
				            			Alert alertType = new Alert(Alert.AlertType.ERROR);
									 alertType.setTitle("ERROR");
									 alertType.setContentText("There's no landline plan. To create a landline contract , create FIRST a landline plan.");
									 alertType.show();
				            		
				            		
				            		
				            		
				            		
				            	}

				            	}
              }
     		// sync our Table
     		OurTableSync();
     		
     		// clear our fields 
     		clearTextFields();
     		  
            }

             
             
              
            
               
            
       		
       		
           
	}
	
		
	
	// if button delete get clicked
			if(event.getSource() == deleteBtn) {
				
			if(	 planField.getText().isEmpty() || phoneField.getText().isEmpty() || typeField.getText().isEmpty() || afmField.getText().isEmpty() ||  payMethodField.getText().isEmpty() || durField.getText().isEmpty() ||dateField.getText().isEmpty()	) {
				Alert alertType = new Alert(Alert.AlertType.ERROR);
				 alertType.setTitle("ERROR");
				 alertType.setContentText("You can't set inactive any contract . Create a contract first");
				 alertType.show();
				}
				
			else {
				
				int datenew= Integer.parseInt(dateField.getText());
				DateTimeFormatter dtf = DateTimeFormatter.ofPattern("uuuuMMdd"); // pairneis thn hmeromhnia tou pc
				LocalDate localDate = LocalDate.now(); // pairneis thn hmeromhnia tou pc
				String shmera = dtf.format(localDate); // pairneis thn hmeromhnia tou pc
				int today=Integer.parseInt(shmera); 
				int ok=0;//timi frouros
				String datenewConv = String.valueOf(datenew);
				char[] digitsdatenew = datenewConv.toCharArray();
				char[] SWAP = new char[8];
				SWAP[3]=digitsdatenew[digitsdatenew.length-1];//kanw to swap apo monh mou dhladh apo morfh ddMMyyyy to kanw yyyyMMdd
				SWAP[2]=digitsdatenew[digitsdatenew.length-2];
				SWAP[1]=digitsdatenew[digitsdatenew.length-3];
				SWAP[0]=digitsdatenew[digitsdatenew.length-4];
				SWAP[5]=digitsdatenew[digitsdatenew.length-5];
				SWAP[4]=digitsdatenew[digitsdatenew.length-6];
				if(digitsdatenew.length==7) {
					SWAP[6]=0;
					SWAP[7]=digitsdatenew[0];}
				else {
					SWAP[6]=digitsdatenew[0];
					SWAP[7]=digitsdatenew[1];
				}
					
				if(SWAP[5]<=2 && SWAP[4]==1) {
					SWAP[5]=(char) (SWAP[5]+1);//EDW VAZW TOUS TREIS MINES. AN EIXA TO CONTRACT:10112021 TOTE TO SWAP EINAI: 20211110 KAI TO SWAP[5] EINAI 1 KAI TO SWAP[4] EINAI 1 . VAZW 3 MHNES THA PAEI 20210210. TO SKEPTIKO EINAI: AN EINAI TO SWAP[5]=2 H 1 H 0 THA EINAI 3 2 1 ANTISTOIXA PROSTHETONTAS TOUS TREIS MINES ARA ME TIN EPOMENH ENTOLH EIMASTE KOMPLEEEEEE 

					SWAP[4]=0;
				}
				else if(SWAP[5]>=7 && SWAP[5]<=9 ) {
					SWAP[5]=(char)(SWAP[5]-7);//PAROMOIO ME TO PANW PX AN EINAI 09 O MHNAS TOTE SWAP5 EINAI 9 TO SWAP4 EINAI 0 THA PREPEI NA GINEI 12 ARA TO SWAP5-7 
					SWAP[4]=1;
				}
				else {
					SWAP[5]=(char)(SWAP[5]+3);
				}

				// an h katastash symvolaiou einai false
				if((Boolean.compare(check, false)==0)) {
					
					Alert alertType = new Alert(Alert.AlertType.ERROR);
					 alertType.setTitle("ERROR");
					 alertType.setContentText("This contract is already non-active.");
					 alertType.show();
					
					
				}
				else{
					//ta kanw arithmous gia tin sugkrish
				int tisSwap=Character.getNumericValue(SWAP[0])*10000000+Character.getNumericValue(SWAP[1])*1000000+Character.getNumericValue(SWAP[2])*100000+Character.getNumericValue(SWAP[3])*10000+Character.getNumericValue(SWAP[4])*1000+Character.getNumericValue(SWAP[5])*100+Character.getNumericValue(SWAP[6])*10+Character.getNumericValue(SWAP[7]);
				if(today<=tisSwap) {
					Alert alertType = new Alert(Alert.AlertType.ERROR);
					alertType.setTitle("WARNING!");
					alertType.setContentText("Since you want to terminate this contract within three months of its existance you have a penalty cost.");
					alertType.show();
					ok=1;
					deleteContract(thisName,ok);
				}
				else {	
					ok=0;
					deleteContract(thisName,ok);
				}

				
			
				// sync our Table
				OurTableSync();
				
				// clear our fields 
				clearTextFields();	
				}
				}  
			}
			
			
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

			
			// if button Search by phone number get Clicked
		    
	    	if(event.getSource() == searchPhoneBtn) {
	    		
	    		if(!(searchPhoneField.getText().isEmpty())) {
	    		
	            Long phone = Long.parseLong(searchPhoneField.getText());
	            OurTableSync();
	            for(Contract a: ContractList)
	            {
	            	// oti den einai idio me to phone poy psaxnei o xrhsths , feugei 
	                if(!(a.getPhone()==phone))
	                    {
	                        contractTableView.getItems().remove(a);

	                    }
	            }
	    			}// end of is empty if
	    	}	
			
			
			// if search button by contract type get clicked (comboBox search)
	    	
	    	// if button Search get Clicked
	        
	    	if(event.getSource() == searchBtn) {
	    		
	    		if(combo1.getSelectionModel().getSelectedIndex()!=1) {
	    		
	    		
	            String type = combo1.getValue();
	            OurTableSync();
	            for(Contract a: ContractList)
	            {
	            	// oti den einai idio me to phone poy psaxnei o xrhsths , feugei 
	               if(!(a.getPlan().equals(type)))
	                    {
	                        contractTableView.getItems().remove(a);

	                    }
	            }
	    			}// end of is nothing selected from combo box , if
	    
	    	}
			
			
		
	
	
	}  // end of event 
	
	// ALL METHODS ARRE HERE
	
	

	
	// method for synchronization our tableView
		public void OurTableSync() {  
	        List<Contract> items = contractTableView.getItems();
	        items.clear();
	        for (Contract a : ContractList) {
	            if (a instanceof Contract) {
	                items.add((Contract) a);
	            }
	        }
	    }
		// METHOD ΤΟ KEEP OUR FIELDS CLEAR.
		public void clearTextFields() {
	        durField.setText("");
	        phoneField.setText("");
	        passField.setText("");
	        dateField.setText("");
	        afmField.setText("");
	        planField.setText("");
	        typeField.setText("");
	        payMethodField.setText("");
	        actField.setText("");
	    }

	
		public void createContract(String pass, long phone, long aFM, String plan, long date, long duration, double discount,
				String payMethod, double afterCost, String type, double cancelCost, boolean active) {
	  	       // create Item named a
	  			Contract a = new Contract( pass,  phone,  aFM,  plan,  date,  duration,  discount,
	  					 payMethod,  afterCost,  type,  cancelCost,  active);
	  	        // we add item a to our list
	  			ContractList.add(a);
		}
		
		
  		
  	// method for deleting a company
  		public void deleteContract(String thisName,int ok) {
  			// SEARCH ON LIST FOR OUR COMPANY NAME
  	        for (int i = 0; i < ContractList.size(); i++) {
  	        	// If we find the name , we delete it.
  	            if (ContractList.get(i).getPass().equals(thisName)) {
  	            	
  	            	if(actField.getText().equals("false")) {
  	            		
  	            		ContractList.get(i).setActive(false);
  	            		
  	            			if(ok==1) {		
  	            		// jana thetw false to editable tou active field
  	            				actField.setEditable(false);
  	            				double CurrCost= ContractList.get(i).getAfterCost();
  	            				CurrCost=ContractList.get(i).getAfterCost()*0.10;
  	            				ContractList.get(i).setCancelCost(CurrCost);
  	            			}
  	            			else {
  	            				ContractList.get(i).setCancelCost(0);

  	            			}
  	            	}
  	            	else {
  	            		Alert alertType = new Alert(Alert.AlertType.ERROR);
  	 				 alertType.setTitle("ERROR");
  	 				 alertType.setContentText("You can only change this to false.");
  	 				 alertType.show();
  	            		
  	            	}
  	            	
  	            	
  	            	
  	            	
  	                break;
  	            }
  	        }
  		}
}