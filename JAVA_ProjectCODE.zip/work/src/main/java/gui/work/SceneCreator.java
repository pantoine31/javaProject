package gui.work;
import javafx.scene.Scene;

// General Scene Creator 

public abstract class SceneCreator {
	
	// fields
	double width;
	double height;


	// Constructor
	public SceneCreator(double width, double height) {
		super();
		this.width = width;
		this.height = height;
	}


	// abstract method for creation 
	abstract Scene createScene();


}
