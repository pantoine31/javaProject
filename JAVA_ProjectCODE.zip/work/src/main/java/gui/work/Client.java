
// CLIENT class

package gui.work;





public class Client {
	
	
// fields	
private String ID;
private long AFM;
private String FullName;
private String Occupation;
private String Address;
private long Phone;
private String Email;


// SETTERS & GETTERS 

public String getID() {
	return ID;
}
public void setID(String iD) {
	ID = iD;
}
public long getAFM() {
	return AFM;
}
public void setAFM(long aFM) {
	AFM = aFM;
}
public String getFullName() {
	return FullName;
}
public void setFullName(String fullName) {
	FullName = fullName;
}
public String getOccupation() {
	return Occupation;
}
public void setOccupation(String occupation) {
	Occupation = occupation;
}
public String getAddress() {
	return Address;
}
public void setAddress(String address) {
	Address = address;
}
public long getPhone() {
	return Phone;
}
public void setPhone(long phone) {
	Phone = phone;
}
public String getEmail() {
	return Email;
}
public void setEmail(String email) {
	Email = email;
}



// CONSTRUCTOR 
public Client(String iD, long aFM, String fullName, String occupation, String address, long phone, String email) {
	super();
	ID = iD;
	AFM = aFM;
	FullName = fullName;
	Occupation = occupation;
	Address = address;
	Phone = phone;
	Email = email;
}






}
