package gui.work;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;

// Scene of Companies
// This scene shows up when we click compBtn


//Creator of Company Scene

//OTI AFORA THN COMPANY SCENE SETARONTAI EDW !!! MESA STON CONSTRUCTOR
public class CompSceneCreator extends SceneCreator implements EventHandler<MouseEvent>{
	
	// constant /// DHLWSH STATHERWN
	private static long Phone;

	private static  String thisName ;

	private static  String Pass;
	
	

			// SETUP CompScene // OTI DHLWNW EINAI EKTOS CONSTRUCTOR
	// Array list for saving our objects. The Type Of our list is TelecommunicationCompany.
			List<TelecommunicationCompany>CompList = new ArrayList<TelecommunicationCompany>();
			
			// Company Scene Flow Pane (root node)   
			FlowPane buttonFlowPane , searchPane;
			
			// Company Scene Grid Pane
			GridPane rootGridPane , inputFieldsPane;
			
			// Buttons of Company Scene
			Button newBtn , refreshBtn , deleteBtn , searchBtn , backBtn;
			
			// Labels of Company Scene (these labels are on inputFieldsPane)
			Label passLbl , nameLbl , phoneLbl , emailLbl , searchLbl, newLbl;
			
			// TextFields of Company Scene (these labels are on inputFieldsPane)
			TextField passField , nameField , phoneField , emailField , searchField;
			
			// TableView of Company Scene (TableView is on flowGridPane)
			TableView<TelecommunicationCompany> compTableView;
	
	// Constructor from superclass
	public CompSceneCreator(double width, double height) {
		super(width, height);
		
		// create objectives
		rootGridPane = new GridPane();
       buttonFlowPane = new FlowPane();
      
      
       
       // Setup Labels of inputFieldsPane 
        nameLbl = new Label("Επωνυμία: ");
        passLbl = new Label("Κωδικός: ");
        phoneLbl = new Label("Τηλέφωνο: ");
        emailLbl = new Label("E-mail: ");
        searchLbl = new Label("Αναζήτηση Εταιρίας: ");
        newLbl = new Label("Στοιχεία Νέας Εταιρίας:");
        
     // Setup text Fields of inputFieldsPane 
        nameField = new TextField();
        passField = new TextField();
        phoneField = new TextField();
        emailField = new TextField();
        searchField = new TextField();
        // non-editable field
        passField.setEditable(false);
        
        // Setup Buttons of GridPane.
        newBtn = new Button("Νέα Εταιρία");
        refreshBtn = new Button("Ενημέρωση");
        deleteBtn = new Button("Διαγραφή");
        backBtn = new Button("Επιστροφή");
        searchBtn = new Button("Αναζήτηση");
        
     // create objectives
        inputFieldsPane = new GridPane();
        compTableView = new TableView<>();
		
		
	// customize flowPane
        // add buttons on flowPane
        buttonFlowPane.setHgap(10);
        buttonFlowPane.setAlignment(Pos.BOTTOM_CENTER);
        
		buttonFlowPane.getChildren().add(newBtn);
		buttonFlowPane.getChildren().add(refreshBtn);
		buttonFlowPane.getChildren().add(deleteBtn);
		buttonFlowPane.getChildren().add(backBtn);
		
	
		// manage of inputFieldsPane
		
		inputFieldsPane.setAlignment(Pos.TOP_RIGHT);
        inputFieldsPane.setVgap(10);
        inputFieldsPane.setHgap(10);
        
        
        inputFieldsPane.add(searchLbl, 0, 0);
        inputFieldsPane.add(searchField, 1, 0);
        inputFieldsPane.add(searchBtn, 0, 1);
        inputFieldsPane.add(newLbl, 0, 2);
        
        inputFieldsPane.add(passLbl, 0, 3);
        inputFieldsPane.add(passField, 1, 3);
        
        inputFieldsPane.add(nameLbl, 0, 4);
        inputFieldsPane.add(nameField, 1, 4);
        inputFieldsPane.add(phoneLbl, 0, 5);
        inputFieldsPane.add(phoneField, 1, 5);
        inputFieldsPane.add(emailLbl, 0, 6);
        inputFieldsPane.add(emailField, 1, 6);
        
        
		
		// manage rootGridPane
        	//Gaps
        rootGridPane.setVgap(10);
        rootGridPane.setHgap(10);
        
      
        // set inputFieldsPane on rootGridPane
        rootGridPane.add(inputFieldsPane, 1, 0);
     // set tableView on rootGridPane
        rootGridPane.add(compTableView, 0, 0);
     // set buttonFlowPane on rootGridPane
        rootGridPane.add(buttonFlowPane, 0, 1);
        rootGridPane.add(backBtn, 1, 1);
      
        
        
     // customize TableView
        // first column
        
        TableColumn<TelecommunicationCompany, String> passColumn = new TableColumn<>("Κωδικός");
        // On the next line , i put "Pass" because in TelecommunicationCompany class our field for password is Pass.
        passColumn.setCellValueFactory(new PropertyValueFactory <>("Pass"));
        compTableView.getColumns().add(passColumn);
        
        // second column
        
        TableColumn<TelecommunicationCompany, String> nameColumn = new TableColumn<>("Επωνυμία");
        // On the next line , i put "Cname" because in TelecommunicationCompany class our field for FullName is Cname.
        nameColumn.setCellValueFactory(new PropertyValueFactory<>("Cname"));
        compTableView.getColumns().add(nameColumn);

        // third column
        TableColumn<TelecommunicationCompany, String> phoneColumn = new TableColumn<>("Τηλέφωνο");
     // On the next line , i put "Phone" because in TelecommunicationCompany class our field for number is Phone.
        phoneColumn.setCellValueFactory(new PropertyValueFactory<>("Phone"));
        compTableView.getColumns().add(phoneColumn);

        
       // forth column 
         TableColumn<TelecommunicationCompany, String> emailColumn = new TableColumn<>("E-Mail");
      // On the next line , i put "Email" because in TelecommunicationCompany class our field for email is Email.
       emailColumn.setCellValueFactory(new PropertyValueFactory<>("Email"));
        compTableView.getColumns().add(emailColumn);
		
		
     // attach handle event to our Buttons  
        
		
		newBtn.setOnMouseClicked(this);
		refreshBtn.setOnMouseClicked(this);
		deleteBtn.setOnMouseClicked(this);
		backBtn.setOnMouseClicked(this);
		compTableView.setOnMouseClicked(this);
		searchBtn.setOnMouseClicked(this);
		
	} // end of CompSceneCreator
	
		
	
	
	
	
	
	// We call Abstract method from SceneCretor Class because we want to create a new scene (HERE WE CREATE OUR COMPANY SCENE).
		@Override
		Scene createScene() {
			
			return new Scene(rootGridPane , width , height);
		}
		
		
		
		
		
		
		
	
	
	
	// Method for Functionality of our buttons
    @Override    public void handle(MouseEvent event) {
    
   
    	// If button Back get clicked ...
    	if(event.getSource() == backBtn) {
            App.primaryStage.setScene(App.mainScene);
            App.primaryStage.setTitle("Κατάστημα Παροχής Τηλεπικοινωνιακών Υπηρεσιών");
        }  
    	
    	// if button Search get Clicked
    
    	if(event.getSource() == searchBtn) {
            String name = searchField.getText();
            OurTableSync();
            for(TelecommunicationCompany a: CompList)
            {
                if(!(a.getCname().equals(name)))
                    {
                        compTableView.getItems().remove(a);

                    }
            }
    	}
    	
    	
    	// if button new get clicked
    	if(event.getSource() == newBtn) {
    	
    		
    		// Generate password for companies
            Random randomNumbers = new Random();

            int Passaki =1 + randomNumbers.nextInt(9999999);

            String Pass = String.valueOf(Passaki);
            passField.setText(String.valueOf(Passaki));

            String Cname = nameField.getText();

            String Email = emailField.getText();
            
            
            
           
         // Use try-catch because we want to check that the user's input gonna be a number.
            
           if(!(phoneField.getText().isEmpty())) { 
            
            try {

             Phone = Long.parseLong(phoneField.getText());
            
            

            

            }catch(IllegalArgumentException e) {

                Alert alertType = new Alert(Alert.AlertType.ERROR);
                alertType.setTitle("Invalid value");
                alertType.setContentText("The value that you gave me for phone is not a number , try again");
                alertType.show();
            }
            
           }
            
            
            
            
            			
            	if (!(phoneField.getText().isEmpty() ) && phoneField.getText().length()!=10) {
            
            	
            	
            		Alert alertType = new Alert(Alert.AlertType.ERROR);
            		alertType.setTitle("Invalid value");
            		alertType.setContentText("Phone number must contains 10 digits , try again");
            		alertType.show();
            	
            		}
            	
            	// check before create a new company all fields are filled.
                if ((emailField.getText().isEmpty() || nameField.getText().isEmpty() || phoneField.getText().isEmpty())) {
            
                	Alert alertType = new Alert(Alert.AlertType.ERROR);
            		alertType.setTitle("Invalid value");
            		alertType.setContentText("Before add a new company you have to fill all fields , Please try again");
            		alertType.show();
            
                }
                
              
            if (!(emailField.getText().isEmpty() || nameField.getText().isEmpty() || phoneField.getText().isEmpty() || phoneField.getText().length()!=10)){
            	 
            	//call createComp method to create our object
            	createComp(Pass , Cname , Phone , Email);
            }
            
            
            
             
            
            
            
    		
    	
        		
        		
        		
    		
                
                
                
    		
    		
    		
    		
    		// sync our Table
    		OurTableSync();
    		
    		// clear our fields 
    		clearTextFields();
    		
    		
    		
    		
    		
    		
    		
        }  
    	
    	// if button refresh get clicked
    	if(event.getSource() == refreshBtn) {
    		
    
    		

            String Cname = nameField.getText();

            String Email = emailField.getText();
            
            
            
           
         // Use try-catch because we want to check that the user's input gonna be a number.
         if(!(phoneField.getText().isEmpty())) {  
            try {

             Phone = Long.parseLong(phoneField.getText());
       
            }catch(NumberFormatException e) {

                Alert alertType = new Alert(Alert.AlertType.ERROR);
                alertType.setTitle("Invalid value");
                alertType.setContentText("The value that you gave me for phone is not a number , try again");
                alertType.show();
            }
            	
        	
         
         if (phoneField.getText().length()!=10) {
            
            	
            	
            		Alert alertType = new Alert(Alert.AlertType.ERROR);
            		alertType.setTitle("Invalid value");
            		alertType.setContentText("Phone number must contains 10 digits , try again");
            		alertType.show();
            	
            		}
         } 	
            	
            	if(!(nameField.getText().isEmpty())) {
                    
                   	
                   	
               		Alert alertType = new Alert(Alert.AlertType.ERROR);
               		alertType.setTitle("Invalid value");
               		alertType.setContentText("Company's name can not change. All other changes were successful.");
               		alertType.show();
               	
               		}
            	
            	// check before refreshing a company !!! We can change only phone and email .
            	
                if ((emailField.getText().isEmpty() ||  phoneField.getText().isEmpty())) {
            
                	Alert alertType = new Alert(Alert.AlertType.ERROR);
            		alertType.setTitle("Invalid value");
            		alertType.setContentText("You can't leave empty email and mobile phone fields , Please try again");
            		alertType.show();
            
                }
                
             
                
            if (!(emailField.getText().isEmpty()  || phoneField.getText().isEmpty() || phoneField.getText().length()!=10) && nameField.getText().isEmpty()){
            	 
            	
            	refreshComp( Phone , Email);
            	

        		// sync our Table
        		OurTableSync();
        		
        		// clear our fields 
        		clearTextFields();
            }
            
    		
    		
    		
    		
        }  
    	
    	// if button delete get clicked
    	if(event.getSource() == deleteBtn) {
           
  	
    	deleteComp(passField.getText());
		// sync our Table
		OurTableSync();
		
		// clear our fields 
		clearTextFields();
    		
    		
    		
        }  
    	
    // if we click on the table view	
    if (event.getSource() == compTableView) {
		//take the item that we clicked on it
		TelecommunicationCompany selectedComp = compTableView.getSelectionModel().getSelectedItem();
		//if this item is not null , then fill textFields
        if (selectedComp != null) {
       
            passField.setText(selectedComp.getPass());
            emailField.setText(selectedComp.getEmail());
            phoneField.setText(Long.toString(selectedComp.getPhone()));
            
            // take company's name to compare on refresh method
           thisName =	selectedComp.getPass();
            
            
            
            
            
        }
    }
    }
    	
    
  //Method For creation item with Comp Type
	
  		public void createComp(String Pass, String Cname, long Phone, String Email) {
  	       // create Item named a
  			TelecommunicationCompany a = new TelecommunicationCompany(Pass, Cname, Phone, Email);
  	        // we add item a to our list
  			CompList.add(a);
  	    }
  		
  		
  	// method for Refreshing our companies
  		public void refreshComp(long Phone , String Email) {
  	        
  	        	for (int i = 0; i < CompList.size(); i++) {
  	        		if(CompList.get(i).getPass().equals(thisName)) {
  	        		
  	        	
  	           
  	            //change whatever we want except name and password
  	            	
  	            	try {
  	            		CompList.get(i).setPhone(Phone);
  	            		CompList.get(i).setEmail(Email);
  	            	
  	            		
  	            	
  	        }catch(NumberFormatException e) {
  	        	  
  	        Alert alertType = new Alert(Alert.AlertType.ERROR);
    		alertType.setTitle("Invalid value");
    		alertType.setContentText("The value that you gave me for phone or for email is not valid , try again");
    		alertType.show();
  	                
  	          		}
  	            
  	        }
  	    }
  		}
  		
  		
  		
  		
  		// method for synchronization our tableView
  		public void OurTableSync() {  
  	        List<TelecommunicationCompany> items = compTableView.getItems();
  	        items.clear();
  	        for (TelecommunicationCompany a : CompList) {
  	            if (a instanceof TelecommunicationCompany) {
  	                items.add((TelecommunicationCompany) a);
  	            }
  	        }
  	    }
  		
  	// method for deleting a company
  		public void deleteComp(String thisName) {
  			// SEARCH ON LIST FOR OUR COMPANY NAME
  	        for (int i = 0; i < CompList.size(); i++) {
  	        	// If we find the name , we delete it.
  	            if (CompList.get(i).getPass().equals(thisName)) {
  	                CompList.remove(i);
  	                break;
  	            }
  	        }
  	    }
  	
  		
  		
  		
  		
  		
  		
  		
  		// METHOD FOR KEEP CLEAR OUR FIELDS.
  		public void clearTextFields() {
  	        nameField.setText("");
  	        phoneField.setText("");
  	        passField.setText("");
  	        emailField.setText("");
  	    }

  	

  	
  	

  	
}
  	