
package gui.work;

import java.awt.event.ActionEvent;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import javax.swing.JComboBox;

import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListCell;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.control.ComboBox;

//Scene of Plans
//This scene shows up when we click planpBtn


public class PlanSceneCreator extends SceneCreator implements EventHandler<MouseEvent> {

	
	
	
	
	
	// Plan Scene Flow Pane (root node)   
		FlowPane buttonFlowPane;
	
	// 	Plan Scene Grid Pane    
	GridPane rootGridPane , inputFieldsPane;
	
	// Buttons of Plan Scene
	Button chBtn , backBtn;
	
	
	
	// Labels of Plan Scene (these labels are on inputFieldsPane)
		Label welLbl;
		
		// CombBox create
		ComboBox<String> comboBox = new ComboBox<String>();
	
	
	
//ComboBox comboBox = new ComboBox();
	
	

	// Constructor for MainScene , everything inside HERE !
	public PlanSceneCreator(double width, double height) {
		
		super(width, height);
		
		// create objectives
				rootGridPane = new GridPane();
				
				buttonFlowPane = new FlowPane();
				
				// Setup Labels of inputFieldsPane 
				
				welLbl = new  Label("Επιλέξτε το είδος προγράμματος .");
				
			// setup buttons
				chBtn = new Button("Επιλογή Προγράμματος");
				backBtn = new Button("Επιστροφή");
				
				
		        
		
		     // create objectives
				inputFieldsPane = new GridPane();
		        
		        
	
		      //set up combo box
			       
		        
			       comboBox.getItems().addAll("---" ,"Landline" , "Mobile"); 
			       comboBox.setPromptText("Επιλογές");			
		        
			       
			       
			       // add buttons on flowPane
			        buttonFlowPane.setHgap(10);
			        buttonFlowPane.setAlignment(Pos.BOTTOM_RIGHT);
			        buttonFlowPane.getChildren().add(chBtn);
			        buttonFlowPane.getChildren().add(backBtn);
			     
			       
		        //set up buttonFlowPane and gridPane
			       inputFieldsPane.setAlignment(Pos.CENTER);
			       inputFieldsPane.add(welLbl, 3, 5);
			       inputFieldsPane.add(comboBox, 3, 6);
			       
			       
			       
			       
			       
			       
			   
			       
			       
			       
		    
		        
			       
			       
			       // manage rootGridPane
			    	//Gaps
			        rootGridPane.setVgap(10);
			        rootGridPane.setHgap(10);
			     // set inputFieldsPane on rootGridPane
			        rootGridPane.add(inputFieldsPane, 2, 5);   
			       rootGridPane.add(buttonFlowPane, 2, 8);
			       
			       
			       
		      
				backBtn.setOnMouseClicked(this);
		        chBtn.setOnMouseClicked(this);
				
		
		
		
		
		
	      

		
		
	}
	
	
	
	
	// We call Abstract method from SceneCretor Class because we want to create a new scene (HERE WE CREATE OUR PLAN SCENE).
	@Override
	Scene createScene() {
		
		return new Scene(rootGridPane , width , height);
	}




	@Override
	public void handle(MouseEvent event) {
		// If button Back get clicked ...
		if(event.getSource() == backBtn) {
            App.primaryStage.setScene(App.mainScene);
            App.primaryStage.setTitle("Κατάστημα Παροχής Τηλεπικοινωνιακών Υπηρεσιών");
        }  
		
		// if user wants Landline Plan 
		 
				if(event.getSource() == chBtn && comboBox.getValue()=="Landline") {
		            App.primaryStage.setScene(App.landScene);
		            App.primaryStage.setTitle("Προγράμματα τύπου LandLine");
		        }  
				
				
				
				// if user wants mobile Plan 
				 
				if(event.getSource() == chBtn && comboBox.getValue()=="Mobile") {
		            App.primaryStage.setScene(App.mobScene);
		            App.primaryStage.setTitle("Προγράμματα τύπου Mobile");
		        }  
				
				if(event.getSource() == chBtn && comboBox.getValue()=="---") {

	                Alert alertType = new Alert(Alert.AlertType.ERROR);
	                alertType.setTitle("Invalid value");
	                alertType.setContentText("You have to choose type of plan, try again");
	                alertType.show();
		        }
				
				
				
				
				
				
			} // END OF MOUSE EVENT
				
				
				
		
				
				
				
				
				
				
				
				
				
				
				
				
	
				
				
				
		
			
			
			
			
			
			
			
			
			
		


  











  		}
    				
  		
		
	


	


