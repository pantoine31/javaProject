package gui.work;



import javafx.application.Application;
import javafx.scene.Scene;

import javafx.stage.Stage;



public class App extends Application {
	
	//Stage
	static Stage primaryStage;

	// Scenes
	static	Scene mainScene,compScene,planScene,clientScene,contractScene, landScene , mobScene;

    @Override
    public void start(Stage primaryStage) {
    	
    	this.primaryStage=primaryStage;
    	
    	
    	// Create MainScene
    	SceneCreator mainSceneCreator = new MainSceneCreator(650,300);
    	mainScene = mainSceneCreator.createScene();
    	
    	// Set Main Scene on stage 
    	primaryStage.setScene(mainScene);
    	primaryStage.setTitle("Κατάστημα Παροχής Τηλεπικοινωνιακών Υπηρεσιών");
    	primaryStage.show();
        
    	// Create CompScene
    	SceneCreator CompSceneCreator = new CompSceneCreator(650,300);
    	compScene = CompSceneCreator.createScene();
    	
    	// Set Comp Scene on stage 
    	
    	primaryStage.setTitle("Διαχείριση Εταιριών Τηλεπικοινωνιών");
    	primaryStage.show();
    	
    	// Create plan Scene
    	SceneCreator PlanSceneCreator = new PlanSceneCreator(650,300);
    	planScene = PlanSceneCreator.createScene();
    	
    	//Set Plan Scene on stage
    	primaryStage.setTitle("Διαχείριση Προγραμμάτων");
    	primaryStage.show();
    	
    	// Create Client Scene
    	SceneCreator ClientsSceneCreator = new ClientsSceneCreator(650,300);
    	clientScene = ClientsSceneCreator.createScene();
    	
    	//Set Client Scene on stage
    	primaryStage.setTitle("Διαχείριση Πελατών");
    	primaryStage.show();
    	
    	
    	
    	// Create a scene for LANDLINE PLANS
    	SceneCreator landLinesSceneCreator = new landLinesSceneCreator(650,300);
    	landScene = landLinesSceneCreator.createScene();
    	

    	//Set landLine plans Scene on stage
    	primaryStage.setTitle("Προγράμματα τύπου LandLine");
    	primaryStage.show();
    	
    	
    	
    	// Create a scene for MOBILE PLANS
    	SceneCreator mobSceneCreator = new mobSceneCreator(650,300);
    	mobScene = mobSceneCreator.createScene();
    	

    	//Set landLine plans Scene on stage
    	primaryStage.setTitle("Προγράμματα τύπου Mobile");
    	primaryStage.show();
    	
    	
    	
    	
    	
    	
    	
    	//Create Contract Scene 
    	SceneCreator ContractSceneCreator = new ContractSceneCreator(650,300);
    	contractScene = ContractSceneCreator.createScene();
    	
    	//Set Contract Scene on stage
    	primaryStage.setTitle("Διαχείριση Συμβολαίων Κινητής ή Σταθερής τηλεφωνίας");
    	primaryStage.show();
    	
    	
    	
    	
    	
    	
    	
    }

    public static void main(String[] args) {
        launch();
    }

}


	