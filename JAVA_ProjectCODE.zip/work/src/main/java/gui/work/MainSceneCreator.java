package gui.work;

import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.FlowPane;

// Creator of Main Scene

// OTI AFORA THN MAIN SCENE SETARONTAI EDW !!! MESA STON CONSTRUCTOR

public class MainSceneCreator extends SceneCreator implements EventHandler<MouseEvent> {
    
	// Main Scene Flow Pane (root node)   
	FlowPane rootFlowPane;
	
	//MAIN SCENE buttons
		Button compBtn, planBtn, clientsBtn, contractsBtn;
		
	// Constructor for MainScene , everything inside HERE !
    public MainSceneCreator(double width, double height) {
    	
        super(width, height);
        
        // Create rootFlowPane
        rootFlowPane = new FlowPane();
        
        
    // Main scene Buttons setup
     	compBtn = new Button("Εταιρίες Τηλεπικοινωνιών");
     	planBtn = new Button("Προγράμματα Κινητής & Σταθερής Τηλεφωνίας");
     	clientsBtn = new Button("Πελάτες");
     	contractsBtn = new Button("Συμβόλαια");
        
        
        
    // attach handle event to Comp Button  
        compBtn.setOnMouseClicked(this);
        planBtn.setOnMouseClicked(this);
        clientsBtn.setOnMouseClicked(this);
        contractsBtn.setOnMouseClicked(this);
        
    // setup Flow Pane
     	rootFlowPane.setAlignment(Pos.CENTER);
     	rootFlowPane.setHgap(10);
     		
     // Add buttons to flow pane
     		rootFlowPane.getChildren().add(compBtn);
     		rootFlowPane.getChildren().add(planBtn);
     		rootFlowPane.getChildren().add(clientsBtn);
     		rootFlowPane.getChildren().add(contractsBtn);
    }
    
    
    // Method for Functionality of compBtn
    @Override    public void handle(MouseEvent event) {
        if(event.getSource() == compBtn) {
            App.primaryStage.setScene(App.compScene);
            App.primaryStage.setTitle("Διαχείριση Εταιριών Τηλεπικοινωνιών");
        } 
        
        
     // Method for Functionality of PlanBtn
        if(event.getSource() == planBtn) {
            App.primaryStage.setScene(App.planScene);
            App.primaryStage.setTitle("Διαχείριση Προγραμμάτων");
        }    
        
     // Method for Functionality of clientsBtn
        if(event.getSource() == clientsBtn) {
            App.primaryStage.setScene(App.clientScene);
            App.primaryStage.setTitle("Διαχείριση Πελατών");
        }    
        
        // Method for Functionality of contractBtn
        if(event.getSource() == contractsBtn) {
            App.primaryStage.setScene(App.contractScene);
            App.primaryStage.setTitle("Διαχείριση Συμβολαίων Κινητής ή Σταθερής τηλεφωνίας");
        }    
        
        
        
        
    }
    
 
    
    // We call Abstract method from SceneCretor Class because we want to create a new scene (HERE WE CREATE OUR MAIN SCENE).
    @Override    Scene createScene() {
        return new Scene(rootFlowPane , width , height);
    }
}