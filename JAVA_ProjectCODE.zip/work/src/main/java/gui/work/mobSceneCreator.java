

package gui.work;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;

public class mobSceneCreator extends SceneCreator implements EventHandler<MouseEvent> {

	// dhlwsh statherwn
		private static  String thisName ;
		
		private static  String Pass;
		private static  int Mins ;
		private static  double Cost;
		private static  int GB ;
		private static  int SMS ;
		private static int ch;
		static int mobCounter = -1; 
		
				static List<Double>costList = new ArrayList<Double>();
				 List<MobilePlan>mList = new ArrayList<MobilePlan>();
				
				// Plan Scene Flow Pane (root node)   
					FlowPane buttonFlowPane;
				
				// 	Plan Scene Grid Pane    
				GridPane rootGridPane , comboPane;
				
				// Buttons of Plan Scene
				Button  sumbBtn ,refreshBtn , deleteBtn , searchBtn , backBtn ;
			
				// Labels of Plan Scene (these labels are on inputFieldsPane)
				Label  programLbl , sumbLbl , passLbl , compLbl , minLbl , costLbl ,  smsLbl ,gbLbl;
			
				// TextFields of Plan Scene (these labels are on inputFieldsPane)
				TextField searchField , passField , compField , minField , costField  , smsField , gbField;
			
				// TableView of Plan Scene (TableView is on flowGridPane)
				TableView<Plan> planTableView;
				
				
				
	// constructor
		public mobSceneCreator(double width, double height) {
			super(width, height);
			
			
			// create objectives
			rootGridPane = new GridPane();
			
			buttonFlowPane = new FlowPane();
			
			// Setup Labels of inputFieldsPane 
			
			programLbl = new Label("Νέο Πρόγραμμα Mobile:");
			passLbl = new Label("Κωδικός:");
			compLbl = new Label("Εταιρία:");
			minLbl = new Label("Λεπτά Ομιλίας:");
			smsLbl = new Label("SMS:");
			gbLbl = new Label("GB:");
			costLbl = new  Label("Κόστος:");
			
			
			// Setup text Fields of comboPane 
			
			searchField = new TextField();
	        passField = new TextField();
	        compField = new TextField();
	        minField = new TextField();
	        costField = new TextField();
	       smsField = new TextField();
	        gbField = new TextField();
	        searchField.setPromptText("Search By Company Name");
			
	     // non-editable field
	        passField.setEditable(false);
	        
	     // Setup Buttons of GridPane.
	        sumbBtn = new Button("Καταχώρηση Νέου Προγράμματος");
	        refreshBtn = new Button("Τροποποίηση");
	        deleteBtn = new Button("Διαγραφή");
	        backBtn = new Button("Επιστροφή");
	        searchBtn = new Button("Αναζήτηση ");
			
	     // create objectives
	        comboPane = new GridPane();
	        planTableView = new TableView<>();
	        
	        
	        // customize flowPane
	        // add buttons on flowPane
	        buttonFlowPane.setHgap(10);
	        buttonFlowPane.setAlignment(Pos.BOTTOM_CENTER);
	        
			buttonFlowPane.getChildren().add(refreshBtn);
			buttonFlowPane.getChildren().add(deleteBtn);
			buttonFlowPane.getChildren().add(backBtn);
	 
			// manage of comboPane
			
			comboPane.setAlignment(Pos.TOP_RIGHT);
			comboPane.setVgap(5);
			comboPane.setHgap(10);
			
			
			comboPane.add(searchField, 0, 0);
			comboPane.add(searchBtn, 0, 1);
			
			
			
			
			comboPane.add(programLbl, 0, 2);
			
			
			
			
			
			comboPane.add(passLbl, 0, 3);
			comboPane.add(passField, 1, 3);
			comboPane.add(compLbl, 0, 4);
			comboPane.add(compField, 1, 4);
			comboPane.add(minLbl, 0, 5);
			comboPane.add(minField, 1, 5);
			
			comboPane.add(smsLbl , 0 , 6 );
			comboPane.add(smsField , 1 ,6);
			comboPane.add(gbLbl , 0 , 7);
			comboPane.add(gbField , 1 , 7);
			
			
			comboPane.add(costLbl, 0, 8);
			comboPane.add(costField, 1, 8);
			comboPane.add(sumbBtn , 1 , 9);
			
			
			
			
			
			
			
			// manage rootGridPane
	    	//Gaps
	        rootGridPane.setVgap(10);
	        rootGridPane.setHgap(10);
	        // set comboPane on rootGridPane
	        rootGridPane.add(comboPane, 1, 0);
	        // set tableView on rootGridPane
	        rootGridPane.add(planTableView, 0, 0);
	        // set buttonFlowPane on rootGridPane
	        rootGridPane.add(buttonFlowPane, 0, 1);
	        rootGridPane.add(backBtn, 1, 1);
			
	     // customize TableView
			
			// first column
	        
	        TableColumn<Plan, String> passColumn = new TableColumn<>("Κωδικός");
	        // On the next line , i put "Pass" because in Plan class our field for password id is Pass.
	        passColumn.setCellValueFactory(new PropertyValueFactory <>("Pass"));
	        passColumn.setPrefWidth(125);
	        planTableView.getColumns().add(passColumn);	
			
	        // Second column
	        
	        TableColumn<Plan, String> companyColumn = new TableColumn<>("Εταιρία");
	        // On the next line , i put "Company" because in Plan class our field for Company is Company.
	        companyColumn.setCellValueFactory(new PropertyValueFactory <>("Company"));
	        companyColumn.setPrefWidth(125);
	        planTableView.getColumns().add(companyColumn);	
	        
	        
	        // Third column
	       
	        TableColumn<Plan, String> minsColumn = new TableColumn<>("Λεπτά Ομιλίας");
	        // On the next line , i put "Mins" because in Plan class our field for minutes is Mins.
	        minsColumn.setCellValueFactory(new PropertyValueFactory <>("Mins"));
	        minsColumn.setPrefWidth(125);
	        planTableView.getColumns().add(minsColumn);	
	        
	      
	     // FOURTH Column
	        TableColumn<Plan, String> speedColumn = new TableColumn<>("SMS/ Ανά Μήνα");
	        speedColumn.setCellValueFactory(new PropertyValueFactory <>("SMS"));
	        speedColumn.setPrefWidth(125);
	        planTableView.getColumns().add(speedColumn);	
	        
	     // FIFTH Column
	        TableColumn<Plan, String> typeColumn = new TableColumn<>("GB/Ανά Μήνα");
	        typeColumn.setCellValueFactory(new PropertyValueFactory <>("GB"));
	        typeColumn.setPrefWidth(125);
	        planTableView.getColumns().add(typeColumn);	
	       
	       
	        // SIXTH Column
	        TableColumn<Plan, String> costColumn = new TableColumn<>("Κόστος");
	        // On the next line , i put "Full Name" because in Client class our field for occupation is occupation.
	        costColumn.setCellValueFactory(new PropertyValueFactory <>("Cost"));
	        costColumn.setPrefWidth(125);
	        planTableView.getColumns().add(costColumn);	
			
			
	        	// BUTTONS GET CLICKED
	        	sumbBtn.setOnMouseClicked(this);
	      		refreshBtn.setOnMouseClicked(this);
	      		deleteBtn.setOnMouseClicked(this);
	      		backBtn.setOnMouseClicked(this);
	      		planTableView.setOnMouseClicked(this);
	      		searchBtn.setOnMouseClicked(this);
	      		
			
			
			
			
			
			
		}

			
			
		

		
		
		
		
		
		@Override
		Scene createScene() {
			
			return new Scene(rootGridPane , width , height);
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		// when buttons get clicked
		@Override
		public void handle(MouseEvent event) {
			
			// If button Back get clicked ...
	    	if(event.getSource() == backBtn) {
	            App.primaryStage.setScene(App.planScene);
	            App.primaryStage.setTitle("Διαχείριση Προγραμμάτων");
	        }
	    	
	    	
	    	// if we click on the table view	
	        if (event.getSource() == planTableView) {
	    		//take the item that we clicked on it
	        	Plan selectedPlan = planTableView.getSelectionModel().getSelectedItem();
	        	// type casting
	        	 MobilePlan selectedMob = (MobilePlan) planTableView.getSelectionModel().getSelectedItem();
	        	
	    		//if this item is not null , then fill textFields
	            if (selectedPlan != null) {
	            //    nameField.setText(selectedComp.getCname());
	                passField.setText(selectedPlan.getPass());
	                
	                
	                
	                
	                minField.setText(Integer.toString(selectedPlan.getMins()));
	    	         smsField.setText(Integer.toString(selectedMob.getSMS()));
	    	       
	    	        gbField.setText(Integer.toString(selectedMob.getGB()));
	    	      
	    	        costField.setText(Double.toString(selectedPlan.getCost()));
	                
	                // take company's name to compare on refresh method
	               thisName =	selectedPlan.getPass();
	                
	                
	                
	                
	                
	            }
	        } // END OF CLICKING ON TABLE VIEW
	        
	        
	        
	        
	        
	    	// if button Search get Clicked
	        
	    	if(event.getSource() == searchBtn) {
	    		
	    		if(searchField.getText().isEmpty()) {
	    			
	    			 Alert alertType = new Alert(Alert.AlertType.ERROR);
		               alertType.setTitle("Error!");
		               alertType.setContentText("You can't search a MOBILE programm by leaving empty search field. Fill the search field. Please ,  try again");
		               alertType.show();	
	    			
	    		}
	    		else {
	    		
	            String name = searchField.getText();
	            OurTableSync();
	            // pairnw ti lista apo th klash Plan , einai static kai koinh gia ta antikeimena typou mobile kai landline
	            for(Plan a: Plan.planList)
	            {
	                if(!(a.getCompany().equals(name)))
	                    {
	                        planTableView.getItems().remove(a);

	                    }
	            }
	    		}
	    	} // END OF SEARCH BTN
	    	
	    	
	    	  // if button sumbBtn get clicked
	    	if(event.getSource() == sumbBtn) {
	    	
	    		
	    		// Generate password for companies
	            Random randomNumbers = new Random();

	            int Passaki =1 + randomNumbers.nextInt(9999999);

	            String Pass = String.valueOf(Passaki);
	            passField.setText(String.valueOf(Passaki));

	           
	           
	                  
	           
	           String Company = compField.getText();
	           
	           
	            
	        // error check
	   		if(  compField.getText().isEmpty() || smsField.getText().isEmpty() || gbField.getText().isEmpty() || costField.getText().isEmpty() || minField.getText().isEmpty() ) {
	       		
	   	    	   Alert alertType = new Alert(Alert.AlertType.ERROR);
	               alertType.setTitle("Inputs Error!");
	               alertType.setContentText("You can't create a new MOBILE programm by leaving empty fields. Fill all fields. Please ,  try again");
	               alertType.show();	
	   	       
	   	       
	   	       
	   	       }
	            
	   				// Make sure that <Minutes Field> , <Cost Field> , <SMS AND GB Field> are numbers!
	   		if(!(minField.getText().isEmpty() || costField.getText().isEmpty() || smsField.getText().isEmpty() || gbField.getText().isEmpty() )	) {	
	   				
	   				try {
	   				
	   	            Mins = Integer.parseInt(minField.getText()); 
	   				Cost = Double.parseDouble(costField.getText());
	   				SMS =Integer.parseInt(smsField.getText());
	   				GB = Integer.parseInt(gbField.getText());
	   				ch = 0;
	   				}catch(NumberFormatException e) {
	   					
	   					
	   					   Alert alertType = new Alert(Alert.AlertType.ERROR);
	   			           alertType.setTitle("Inputs Error!");
	   			           alertType.setContentText("One of the follow fields: <Minutes Field> , <Cost Field> , <SMS or GB Field> is not a number! Please ,  try again");
	   			           alertType.show();
	   					ch = 1;
	   					
	   					
	   				}
	   		}
	   				
	   				// if everything is ok we create our plan
	           if((!( ch == 1 || compField.getText().isEmpty() || smsField.getText().isEmpty() || gbField.getText().isEmpty() || costField.getText().isEmpty() || minField.getText().isEmpty()))) { 
	        	   	
	        	   createLand(Pass, Company, Mins, Cost , SMS , GB);
	        	   
	        	   // every time that i create a mobPlan mobCount = mbCounter+1 // check on contract
	        	   mobCounter=mobCounter+1;
	        	   costList.add(mobCounter, Cost);
	        	  
	           }
	     		
	     	// sync our Table
	    		OurTableSync();
	    		
	    		// clear our fields 
	    		clearTextFields();
		       
		       
		       
		        
	        
	        
	        
	        
	        
	    	} // end of sumbBtn
	    	
	    	
	    	// IF refresh btn get clicked
	    	if(event.getSource() == refreshBtn) {
	    	
	    		
	    		
	           
	            
	        // error check
	   		if(   smsField.getText().isEmpty() || gbField.getText().isEmpty() || costField.getText().isEmpty() || minField.getText().isEmpty() ) {
	       		
	   	    	   Alert alertType = new Alert(Alert.AlertType.ERROR);
	               alertType.setTitle("Inputs Error!");
	               alertType.setContentText("You can't refresh a MOBILE programm by leaving empty fields. Fill all fields. Please ,  try again");
	               alertType.show();	
	   	       
	   	       
	   	       
	   	       }
	            
	   				// Make sure that <Minutes Field> , <Cost Field> , <SMS AND GB Field> are numbers!
	   		if(!(minField.getText().isEmpty() || costField.getText().isEmpty() || smsField.getText().isEmpty() || gbField.getText().isEmpty() )	) {	
	   				
	   				try {
	   				
	   	            Mins = Integer.parseInt(minField.getText()); 
	   				Cost = Double.parseDouble(costField.getText());
	   				SMS =Integer.parseInt(smsField.getText());
	   				GB = Integer.parseInt(gbField.getText());
	   				 ch = 0;
	   				
	   				}catch(NumberFormatException e) {
	   					
	   					
	   					   Alert alertType = new Alert(Alert.AlertType.ERROR);
	   			           alertType.setTitle("Inputs Error!");
	   			           alertType.setContentText("One of the follow fields: <Minutes Field> , <Cost Field> , <SMS or GB Field> is not a number! Please ,  try again");
	   			           alertType.show();
	   			           ch = 1;
	   					
	   					
	   				}
	   		}
	   		
	   	// check that the company's name cant change
     		if(!(compField.getText().isEmpty())) {
     			 Alert alertType = new Alert(Alert.AlertType.ERROR);
		           alertType.setTitle("Inputs Error!");
		           alertType.setContentText(" Company's name can not change! Please ,  try again");
		           alertType.show();
     		}
	   				
	   				// if everything is ok we create our plan
	           if((!( ch == 1 || smsField.getText().isEmpty() || gbField.getText().isEmpty() || costField.getText().isEmpty() || minField.getText().isEmpty()))) { 
	        	   	
	        	  refreshPlan(Mins, Cost , SMS , GB);
	           }
	     		
	     	// sync our Table
	    		OurTableSync();
	    		
	    		// clear our fields 
	    		clearTextFields();
		       
		       
		       
		        
	        
	        
	        
	        
	        
	    	} // end ofrefreshBtn
	    	
	    	
	    	// if button delete get clicked
	    	if(event.getSource() == deleteBtn) {
	           
	  	
	    	deleteComp(passField.getText());
			// sync our Table
			OurTableSync();
			
			// clear our fields 
			clearTextFields();
	    		
	    		
	    		
	        }  
	    	
	    	
	    	
	    	
	    	
	    	
	    	
	    	
	    	
	    	
	    	
	    	
	    	
	    	
	    	
	    	
	    	
	    	
	    	
	    	
	    	
	    	
	    	
	    	
	    	
	    	
	    	
	    	
	    	
	    	
	    	
	    	
	    	
	    	
	    	
	    	
	    	
	    	
	    	
	    	
	    	
	    	
	    	
	    	
	    	
	    	
	    	
	    	
	    	
	    	
			
			
		} // end of event 
		
		
		
		// all methods are here
		
		// method for synchronization our tableView
			public void OurTableSync() {  
		        List<Plan> items = planTableView.getItems();
		        items.clear();
		        for (Plan f: Plan.planList) {
		            if (f instanceof MobilePlan) {
		                items.add((MobilePlan) f);
		            }
		        }
		    }
			
		// method for deleting a plan
			public void deleteComp(String thisName) {
				// SEARCH ON LIST FOR OUR password 
		        for (int i = 0; i < Plan.planList.size(); i++) {
		        	// If we find the name , we delete it.
		            if (Plan.planList.get(i).getPass().equals(thisName)) {
		            	Plan.planList.remove(i);
		                break;
		            }
		        }
		    }
		
			
			
			//Method For creation item with Mobile Type
			
	  		public void createLand(String pass, String company, int mins, double cost, int sMS, int gB ){
	  	       // create Item named a
	  			Plan f = new MobilePlan(pass, company, mins, cost , SMS , GB);
	  	        // we add item a to our list
	  			Plan.planList.add((MobilePlan) f);
	  			
	  	    }
			
	  	
	  		
	  		
	  		// method for Refreshing our plans
	  		public void refreshPlan( int mins, double cost, int GB, int SMS) {
	  			
	  			for (int i = 0; i < Plan.planList.size(); i++) {
		        		if(Plan.planList.get(i).getPass().equals(thisName)) {
		        			// change whatever we want except password and company's name
		        			
		        			Plan.planList.get(i).setCost(cost);
		        			Plan.planList.get(i).setMins(mins);
		        			// type casting to see sms and gb field
		        			((MobilePlan) Plan.planList.get(i)).setSMS(SMS);
		        			((MobilePlan) Plan.planList.get(i)).setGB(GB);

		        			
		        			
		        			
		        			
		        			
		        		}
	  			}
	  			
	  			
	  		}
	  		
	  		
	  		
	  		
	  		
	  		
	  		
	  		
	  		
	  		
	  		
	  		
	  		
	  		
	  		
	  		
	  		
	  		
	  		
	  		
	  		
	  		
			
			// METHOD FOR KEEP CLEAR OUR FIELDS.
			public void clearTextFields() {
				minField.setText("");
		        smsField.setText("");
		        passField.setText("");
		        gbField.setText("");
		        compField.setText("");
		        costField.setText("");
		    }

		

		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

}


