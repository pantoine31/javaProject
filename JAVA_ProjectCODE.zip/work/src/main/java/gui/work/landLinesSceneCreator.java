

package gui.work;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;

public class landLinesSceneCreator extends SceneCreator implements EventHandler<MouseEvent> {

	// dhlwsh statherwn
	private static  String thisName ;
	
	private static  String Pass;
	private static  int Mins ;
	private static  double Cost;
	private static  int Speed ;
	private static int ch;
	static int landCounter = -1;
	
	// Array list for saving our objects. The Type Of our list is Plan.
		
		static List<Double>costList = new ArrayList<Double>();
		
		
		// Plan Scene Flow Pane (root node)   
			FlowPane buttonFlowPane;
		
		// 	Plan Scene Grid Pane    
		GridPane rootGridPane , comboPane;
		
		// Buttons of Plan Scene
		Button  sumbBtn ,refreshBtn , deleteBtn , searchBtn , backBtn ;
	
		// Labels of Plan Scene (these labels are on inputFieldsPane)
		Label  programLbl , sumbLbl , passLbl , compLbl , minLbl , costLbl ,  speedLbl ,typeLbl;
	
		// TextFields of Plan Scene (these labels are on inputFieldsPane)
		TextField searchField , passField , compField , minField , costField  , speedField , typeField;
	
		// TableView of Plan Scene (TableView is on flowGridPane)
		TableView<Plan> planTableView;
	
	// constructor
	public landLinesSceneCreator(double width, double height) {
		super(width, height);
		
		
		// create objectives
		rootGridPane = new GridPane();
		
		buttonFlowPane = new FlowPane();
		
		// Setup Labels of inputFieldsPane 
		
		programLbl = new Label("Νέο Πρόγραμμα landline:");
		passLbl = new Label("Κωδικός:");
		compLbl = new Label("Εταιρία:");
		minLbl = new Label("Λεπτά Ομιλίας:");
		speedLbl = new Label("Ταχύτητα Γραμμής:");
		typeLbl = new Label("Τύπος Γραμμής:");
		costLbl = new  Label("Κόστος:");
		
		
		// Setup text Fields of comboPane 
		
		searchField = new TextField();
        passField = new TextField();
        compField = new TextField();
        minField = new TextField();
        costField = new TextField();
        speedField = new TextField();
        typeField = new TextField();
        searchField.setPromptText("Search By Company Name");
		
     // non-editable field
        passField.setEditable(false);
        
     // Setup Buttons of GridPane.
        sumbBtn = new Button("Καταχώρηση Νέου Προγράμματος");
        refreshBtn = new Button("Τροποποίηση");
        deleteBtn = new Button("Διαγραφή");
        backBtn = new Button("Επιστροφή");
        searchBtn = new Button("Αναζήτηση ");
       
     // create objectives
        comboPane = new GridPane();
        planTableView = new TableView<>();
        
        
        // customize flowPane
        // add buttons on flowPane
        buttonFlowPane.setHgap(10);
        buttonFlowPane.setAlignment(Pos.BOTTOM_CENTER);
        
		buttonFlowPane.getChildren().add(refreshBtn);
		buttonFlowPane.getChildren().add(deleteBtn);
		buttonFlowPane.getChildren().add(backBtn);
 
		// manage of comboPane
		
		comboPane.setAlignment(Pos.TOP_RIGHT);
		comboPane.setVgap(5);
		comboPane.setHgap(10);
		
		
		comboPane.add(searchField, 0, 0);
		comboPane.add(searchBtn, 0, 1);
		
		
		
		
		comboPane.add(programLbl, 0, 2);
		
		
		
		
		
		comboPane.add(passLbl, 0, 3);
		comboPane.add(passField, 1, 3);
		comboPane.add(compLbl, 0, 4);
		comboPane.add(compField, 1, 4);
		comboPane.add(minLbl, 0, 5);
		comboPane.add(minField, 1, 5);
		
		comboPane.add(speedLbl , 0 , 6 );
		comboPane.add(speedField , 1 ,6);
		comboPane.add(typeLbl , 0 , 7);
		comboPane.add(typeField , 1 , 7);
		
		
		comboPane.add(costLbl, 0, 8);
		comboPane.add(costField, 1, 8);
		comboPane.add(sumbBtn , 1 , 9);
		
		
		
		
		
		
		
		// manage rootGridPane
    	//Gaps
        rootGridPane.setVgap(10);
        rootGridPane.setHgap(10);
        // set comboPane on rootGridPane
        rootGridPane.add(comboPane, 1, 0);
        // set tableView on rootGridPane
        rootGridPane.add(planTableView, 0, 0);
        // set buttonFlowPane on rootGridPane
        rootGridPane.add(buttonFlowPane, 0, 1);
        rootGridPane.add(backBtn, 1, 1);
        
        
      
		
		
		// customize TableView
		
		// first column
        
        TableColumn<Plan, String> passColumn = new TableColumn<>("Κωδικός");
        // On the next line , i put "Pass" because in Plan class our field for password id is Pass.
        passColumn.setCellValueFactory(new PropertyValueFactory <>("Pass"));
        passColumn.setPrefWidth(125);
        planTableView.getColumns().add(passColumn);	
		
        // Second column
        
        TableColumn<Plan, String> companyColumn = new TableColumn<>("Εταιρία");
        // On the next line , i put "Company" because in Plan class our field for Company is Company.
        companyColumn.setCellValueFactory(new PropertyValueFactory <>("Company"));
        companyColumn.setPrefWidth(125);
        planTableView.getColumns().add(companyColumn);	
        
        
        // Third column
       
        TableColumn<Plan, String> minsColumn = new TableColumn<>("Λεπτά Ομιλίας");
        // On the next line , i put "Mins" because in Plan class our field for minutes is Mins.
        minsColumn.setCellValueFactory(new PropertyValueFactory <>("Mins"));
        minsColumn.setPrefWidth(125);
        planTableView.getColumns().add(minsColumn);	
        
      
     // FOURTH Column
        TableColumn<Plan, String> speedColumn = new TableColumn<>("Ταχύτητα Γραμμής");
        speedColumn.setCellValueFactory(new PropertyValueFactory <>("Speed"));
        speedColumn.setPrefWidth(125);
        planTableView.getColumns().add(speedColumn);	
        
     // FIFTH Column
        TableColumn<Plan, String> typeColumn = new TableColumn<>("Τύπος Γραμμής");
        typeColumn.setCellValueFactory(new PropertyValueFactory <>("Type"));
        typeColumn.setPrefWidth(125);
        planTableView.getColumns().add(typeColumn);	
       
       
        // SIXTH Column
        TableColumn<Plan, String> costColumn = new TableColumn<>("Κόστος");
        // On the next line , i put "Full Name" because in Client class our field for occupation is occupation.
        costColumn.setCellValueFactory(new PropertyValueFactory <>("Cost"));
        costColumn.setPrefWidth(125);
        planTableView.getColumns().add(costColumn);	
		
		
        	// BUTTONS GET CLICKED
        	sumbBtn.setOnMouseClicked(this);
      		refreshBtn.setOnMouseClicked(this);
      		deleteBtn.setOnMouseClicked(this);
      		backBtn.setOnMouseClicked(this);
      		planTableView.setOnMouseClicked(this);
      		searchBtn.setOnMouseClicked(this);
      		
		
		
		
		
		
		
	}

	
	
	
	
	
	
	@Override
	Scene createScene() {
		
		return new Scene(rootGridPane , width , height);
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	// when buttons get clicked
	@Override
	public void handle(MouseEvent event) {
		
		// If button Back get clicked ...
    	if(event.getSource() == backBtn) {
            App.primaryStage.setScene(App.planScene);
            App.primaryStage.setTitle("Διαχείριση Προγραμμάτων");
        }  
    	
    	
    	
    	// if button Search get Clicked
        
    	if(event.getSource() == searchBtn) {
    		if(searchField.getText().isEmpty()) {
    			
   			 Alert alertType = new Alert(Alert.AlertType.ERROR);
	               alertType.setTitle("Error!");
	               alertType.setContentText("You can't search a MOBILE programm by leaving empty search field. Fill the search field. Please ,  try again");
	               alertType.show();	
   			
   		}
    		else {
            String name = searchField.getText();
            OurTableSync();
            for(Plan a: Plan.planList)
            {
                if(!(a.getCompany().equals(name)))
                    {
                        planTableView.getItems().remove(a);

                    }
            }
    		}
    	} // END OF SEARCH BTN
    	
    	
    	// if we click on the table view	
        if (event.getSource() == planTableView) {
    		//take the item that we clicked on it
        	Plan selectedPlan = planTableView.getSelectionModel().getSelectedItem();
        	// type casting
        	LandlinePlan selectedLand = (LandlinePlan) planTableView.getSelectionModel().getSelectedItem();
    		//if this item is not null , then fill textFields
            if (selectedPlan != null) {
            //    nameField.setText(selectedComp.getCname());
                passField.setText(selectedPlan.getPass());
                
                
                
                
                minField.setText(Integer.toString(selectedPlan.getMins()));
    	        speedField.setText(Integer.toString(selectedLand.getSpeed()));
    	       
    	        typeField.setText(selectedLand.getType());
    	      
    	        costField.setText(Double.toString(selectedPlan.getCost()));
                
                // take company's name to compare on refresh method
               thisName =	selectedPlan.getPass();
                
                
                
                
                
            }
        } // END OF CLICKING ON TABLE VIEW
        
        
     // if button delete get clicked
    	if(event.getSource() == deleteBtn) {
           
  	
    	deleteComp(passField.getText());
		// sync our Table
		OurTableSync();
		
		// clear our fields 
		clearTextFields();
    		
    		
    		
        }  
        
     // if button sumbBtn get clicked
    	if(event.getSource() == sumbBtn) {
    	
    		
    		// Generate password for companies
            Random randomNumbers = new Random();

            int Passaki =1 + randomNumbers.nextInt(9999999);

            String Pass = String.valueOf(Passaki);
            passField.setText(String.valueOf(Passaki));

           
           
           String Type = typeField.getText();
           
           String Company = compField.getText();
           
           
            
        // error check
   		if(  compField.getText().isEmpty() || speedField.getText().isEmpty() || typeField.getText().isEmpty() || costField.getText().isEmpty() || minField.getText().isEmpty() ) {
       		
   	    	   Alert alertType = new Alert(Alert.AlertType.ERROR);
               alertType.setTitle("Inputs Error!");
               alertType.setContentText("You can't create a new LandLine programm by leaving empty fields. Fill all fields. Please ,  try again");
               alertType.show();	
   	       
   	       
   	       
   	       }
            
   				// make sure that type is adsl or vdsl
		if(!(typeField.getText().isEmpty())) {
   				if(!( typeField.getText().equals("adsl")|| typeField.getText().equals("ADSL")|| typeField.getText().equals("vdsl")|| typeField.getText().equals("VDSL"))) {
   	    			Alert alertType = new Alert(Alert.AlertType.ERROR);
   	                alertType.setTitle("Invalid value for <Τύπος Γραμμής>");
   	                alertType.setContentText("Valid inputs for <Τύπος Γραμμής> : vdsl/adsl/ OR VDSL/ADSL");
   	                alertType.show();
   	    		}
   				
		}
   				
   				// Make sure that <Minutes Field> , <Cost Field> , <Speed Field> are numbers!
   		if(!(minField.getText().isEmpty() || costField.getText().isEmpty() || speedField.getText().isEmpty()  )	) {	
   				
   				try {
   				
   	            Mins = Integer.parseInt(minField.getText()); 
   				Cost = Double.parseDouble(costField.getText());
   				
   				Speed = Integer.parseInt(speedField.getText());
   				ch = 0;
   				
   				}catch(NumberFormatException e) {
   					ch = 1;
   					
   					   Alert alertType = new Alert(Alert.AlertType.ERROR);
   			           alertType.setTitle("Inputs Error!");
   			           alertType.setContentText("One of the follow fields: <Minutes Field> , <Cost Field> , <Speed Field> is not a number! Please ,  try again");
   			           alertType.show();
   					
   					
   					
   				}
   		}
   				
   				// if everything is ok we create our plan
           if(( typeField.getText().equals("adsl")|| typeField.getText().equals("ADSL")|| typeField.getText().equals("vdsl")|| typeField.getText().equals("VDSL") && (!( ch ==1 || compField.getText().isEmpty() || speedField.getText().isEmpty() || typeField.getText().isEmpty() || costField.getText().isEmpty() || minField.getText().isEmpty())))) { 
        	   	
        	   createLand(Pass, Company, Mins, Cost , Speed , Type);
        	   
        	   
        	   // every time that i create a mobPlan landCounter = landCounter+1 // check on contract
        	   landCounter=landCounter+1;
        	   costList.add(landCounter, Cost);
        	  
        	   
        	 
        	   
        	   
        	   
           }
     		
     	// sync our Table
    		OurTableSync();
    		
    		// clear our fields 
    		clearTextFields();
	       
	       
	       
	        
        
        
        
        
        
    	} // end of sumbBtn
        
        
        // if button regresh get clicked
    	
    	if(event.getSource()==refreshBtn) {
    		
    		
    		
    		 String Type = typeField.getText();
             
             String Company = compField.getText();
             
             
              
          // error check
     		if( speedField.getText().isEmpty() || typeField.getText().isEmpty() || costField.getText().isEmpty() || minField.getText().isEmpty() ) {
         		
     	    	   Alert alertType = new Alert(Alert.AlertType.ERROR);
                 alertType.setTitle("Inputs Error!");
                 alertType.setContentText("You can't refresh a LandLine programm by leaving all fields empty. Fill all fields. Please ,  try again");
                 alertType.show();	
     	       
     	       
     	       
     	       }
              
     				// make sure that type is adsl or vdsl
  		if(!(typeField.getText().isEmpty())) {
     				if(!( typeField.getText().equals("adsl")|| typeField.getText().equals("ADSL")|| typeField.getText().equals("vdsl")|| typeField.getText().equals("VDSL"))) {
     	    			Alert alertType = new Alert(Alert.AlertType.ERROR);
     	                alertType.setTitle("Invalid value for <Τύπος Γραμμής>");
     	                alertType.setContentText("Valid inputs for <Τύπος Γραμμής> : vdsl/adsl/ OR VDSL/ADSL");
     	                alertType.show();
     	    		}
     				
  		}
     				
     				// Make sure that <Minutes Field> , <Cost Field> , <Speed Field> are numbers!
     		if(!(minField.getText().isEmpty() || costField.getText().isEmpty() || speedField.getText().isEmpty()  )	) {	
     				
     				try {
     				
     	            Mins = Integer.parseInt(minField.getText()); 
     				Cost = Double.parseDouble(costField.getText());
     				
     				Speed = Integer.parseInt(speedField.getText());
     				
     				ch =0 ;
     				}catch(NumberFormatException e) {
     					ch = 1;
     					
     					   Alert alertType = new Alert(Alert.AlertType.ERROR);
     			           alertType.setTitle("Inputs Error!");
     			           alertType.setContentText("One of the follow fields: <Minutes Field> , <Cost Field> , <Speed Field> is not a number! Please ,  try again");
     			           alertType.show();
     					
     					
     					
     				}
     		}
     		
     		// check that the company's name cant change
     		if(!(compField.getText().isEmpty())) {
     			 Alert alertType = new Alert(Alert.AlertType.ERROR);
		           alertType.setTitle("Inputs Error!");
		           alertType.setContentText(" Company's name can not change! Please ,  try again");
		           alertType.show();
     		}
     		
     		
     		
     				
     				// if everything is ok we create our plan
             if((compField.getText().isEmpty()) && ( typeField.getText().equals("adsl")|| typeField.getText().equals("ADSL")|| typeField.getText().equals("vdsl")|| typeField.getText().equals("VDSL") && (!( ch == 1 ||compField.getText().isEmpty() || speedField.getText().isEmpty() || typeField.getText().isEmpty() || costField.getText().isEmpty() || minField.getText().isEmpty())))) { 
          	   	
          	   refreshPlan( Mins, Cost , Speed , Type);
             }
       		
       	// sync our Table
      		OurTableSync();
      		
      		// clear our fields 
      		clearTextFields();
    		
    		
    		
    		
    		
    		
    		
    		
    		
    		
    		
    		
    		
    		
    		
    		
    		
    		
    		
    		
    		
    		
    		
    		
    		
    		
    		
    		
    		
    		
    		
    		
    		
    		
    		
    		
    		
    		
    		
    		
    		
    		
    	} // end of refreshing btn
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
    	
    	
    	
		
		
	}
	
	
	
	// all methods are here
	
	// method for synchronization our tableView
		public void OurTableSync() {  
	        List<Plan> items = planTableView.getItems();
	        items.clear();
	        for (Plan a : Plan.planList) {
	            if (a instanceof LandlinePlan) {
	                items.add((LandlinePlan) a);
	            }
	        }
	    }
		
	// method for deleting a company
		public void deleteComp(String thisName) {
			// SEARCH ON LIST FOR OUR COMPANY NAME
	        for (int i = 0; i < Plan.planList.size(); i++) {
	        	// If we find the name , we delete it.
	            if (Plan.planList.get(i).getPass().equals(thisName)) {
	            	Plan.planList.remove(i);
	                break;
	            }
	        }
	    }
	
		
		
		//Method For creation item with LandLine Type
		
  		public void createLand(String pass, String company, int mins, double cost, int speed, String type) {
  	       // create Item named a
  			Plan a = new LandlinePlan(pass, company, mins, cost , speed , type);
  	        // we add item a to our list
  			Plan.planList.add((LandlinePlan) a);
  			
  	    }
		
  	
  		
  		
  		// method for Refreshing our plans
  		public void refreshPlan( int mins, double cost, int speed, String type) {
  			
  			for (int i = 0; i < Plan.planList.size(); i++) {
	        		if((Plan.planList.get(i).getPass().equals(thisName))) {
	        			// change whatever we want except password and company's name
	        			
	        			Plan.planList.get(i).setCost(cost);
	        			Plan.planList.get(i).setMins(mins);
	        			((LandlinePlan) Plan.planList.get(i)).setSpeed(speed);
	        			((LandlinePlan) Plan.planList.get(i)).setType(type);
	        			
	        			
	        			
	        		}
  			}
  			
  			
  		}
  		
  		
  		
  		
  		
  		
  		
  		
  		
  		
  		
  		
  		
  		
  		
  		
  		
  		
  		
  		
  		
  		
		
		// METHOD FOR KEEP CLEAR OUR FIELDS.
		public void clearTextFields() {
			minField.setText("");
	        speedField.setText("");
	        passField.setText("");
	        typeField.setText("");
	        compField.setText("");
	        costField.setText("");
	    }

	

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

	

}
