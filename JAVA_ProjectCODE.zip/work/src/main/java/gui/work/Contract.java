// CONTRACT class


package gui.work;
public class Contract {

    
// fields    
    
private String Pass;
private long Phone;
private long AFM;
private String Plan; //programma
private long Date;
private long Duration;
private double Discount;
private String PayMethod;
private double AfterCost;
private String Type;
private double CancelCost;
private boolean Active;


// SETTERS & GETTERS ��� ������ CONTRACT

public String getPass() {
    return Pass;
}
public void setPass(String pass) {
    Pass = pass;
}
public long getPhone() {
    return Phone;
}
public void setPhone(long phone) {
    Phone = phone;
}
public long getAFM() {
    return AFM;
}
public void setAFM(long aFM) {
    AFM = aFM;
}
public String getPlan() {
    return Plan;
}
public void setPlan(String plan) {
    Plan = plan;
}
public long getDate() {
    return Date;
}
public void setDate(long date) {
    Date = date;
}
public long getDuration() {
    return Duration;
}
public void setDuration(long duration) {
    Duration = duration;
}
public double getDiscount() {
    return Discount;
}
public void setDiscount(double discount) {
    Discount = discount;
}
public String getPayMethod() {
    return PayMethod;
}
public void setPayMethod(String payMethod) {
    PayMethod = payMethod;
}
public double getAfterCost() {
    return AfterCost;
}
public void setAfterCost(double afterCost) {
    AfterCost = afterCost;
}
public String getType() {
    return Type;
}
public void setType(String type) {
    Type = type;
}
public double getCancelCost() {
    return CancelCost;
}
public void setCancelCost(double cancelCost) {
    CancelCost = cancelCost;
}
public boolean isActive() {
    return Active;
}
public void setActive(boolean active) {
    Active = active;
}


// CONSTRUCTOR 

public Contract(String pass, long phone, long aFM, String plan, long date, long duration, double discount,
        String payMethod, double afterCost, String type, double cancelCost, boolean active) {
    super();
    Pass = pass;
    Phone = phone;
    AFM = aFM;
    Plan = plan;
    Date = date;
    Duration = duration;
    Discount = discount;
    PayMethod = payMethod;
    AfterCost = afterCost;
    Type = type;
    CancelCost = cancelCost;
    Active = active;
}
}