
//MobilePlan class


package gui.work;

public class MobilePlan extends Plan {
	
	
// fields
	
private int SMS;
private int GB;

// SETTERS & GETTERS 

public int getSMS() {
	return SMS;
}
public void setSMS(int sMS) {
	SMS = sMS;
}
public int getGB() {
	return GB;
}
public void setGB(int gB) {
	GB = gB;
}

// CONSTRUCTOR 

public MobilePlan(String pass, String company, int mins, double cost, int sMS, int gB) {
	super(pass, company, mins, cost);
	SMS = sMS;
	GB = gB;
}

}
