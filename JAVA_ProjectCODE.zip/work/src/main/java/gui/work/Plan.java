
// Plan class


package gui.work;

import java.util.ArrayList;
import java.util.List;

public class Plan {
	
	// list for saving our objects
	static List<Plan>planList = new ArrayList<Plan>();

	
	
	
	//fields	
private String Pass;
private String Company;
private int Mins;
private double Cost;


// SETTERS & GETTERS 

public String getPass() {
	return Pass;
}
public void setPass(String pass) {
	Pass = pass;
}
public String getCompany() {
	return Company;
}
public void setCompany(String company) {
	Company = company;
}
public int getMins() {
	return Mins;
}
public void setMins(int mins) {
	Mins = mins;
}
public double getCost() {
	return Cost;
}
public void setCost(double cost) {
	Cost = cost;
}


// CONSTRACTOR

public Plan(String pass, String company, int mins, double cost) {
	super();
	Pass = pass;
	Company = company;
	Mins = mins;
	Cost = cost;
}

}
