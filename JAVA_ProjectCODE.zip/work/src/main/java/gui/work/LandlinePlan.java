
// LandlinePlan Class


package gui.work;

public class LandlinePlan extends Plan{
	
	// fields
	
	private int Speed;
	private String Type;
	
	// SETTERS & GETTERS 
	
	public int getSpeed() {
		return Speed;
	}
	public void setSpeed(int speed) {
		Speed = speed;
	}
	public String getType() {
		return Type;
	}
	public void setType(String type) {
		Type = type;
	}
	
	// CONSTRTUCTOR 
	
	public LandlinePlan(String pass, String company, int mins, double cost, int speed, String type) {
		super(pass, company, mins, cost);
		Speed = speed;
		Type = type;
	}
	
}
